﻿Imports System.Data.OleDb
Module BDD
    'ruta de inicio del proyecto sln
    Dim inicio As String = System.AppDomain.CurrentDomain.BaseDirectory
    'formato ruta de la bdd
    Public ruta As String = inicio.Substring(0, inicio.LastIndexOf("\", inicio.LastIndexOf("\", inicio.LastIndexOf("\", inicio.LastIndexOf("\") - 1) - 1) - 1)) & "\"

    Dim ConectString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ruta & "EMPRESA.MDB"
    Public BDCON As OleDbConnection = New OleDbConnection(ConectString)
    'BDD donde se guardan todas las tablas en el adaptador.
    Public almacen As New almacenReport
    'Adaptador para manejo de datos del almacen.
    Public adaptador As OleDbDataAdapter

    'Metodo conectar a la base de datos.
    Public Sub conectar()
        If Not BDCON.State = ConnectionState.Open Then
            BDCON.Open()
        End If
    End Sub
    'Metodo desconectar a la base de datos.
    Public Sub desconectar()
        If BDCON.State = ConnectionState.Open Then
            BDCON.Close()
        End If
    End Sub
    'Metodo de carga del almacen y seteo de relaciones y claves primarias.
    Public Sub cargarAlmacen()
        Dim userTables As DataTable
        almacen.Reset()
        Reto.conectar()
        userTables = BDCON.GetOleDbSchemaTable(OleDb.OleDbSchemaGuid.Tables, New String() {Nothing, Nothing, Nothing, Nothing})

        Dim SQL As String
        Dim consulta As OleDbCommand
        Dim oledbCmdBuilder As OleDbCommandBuilder

        For i = 0 To userTables.Rows.Count - 1
            If Not userTables.Rows(i)(2).ToString().Contains("MSys") Then
                SQL = "Select * from " & userTables.Rows(i)(2).ToString()
                consulta = New OleDbCommand(SQL, BDCON)
                adaptador = New OleDbDataAdapter(consulta)
                oledbCmdBuilder = New OleDbCommandBuilder(adaptador)
                adaptador.Fill(almacen, userTables.Rows(i)(2).ToString())
            End If
        Next

        Reto.desconectar()

        'Para que se pueda borrar/actualizar/insertar correctamente se debe activar on cascade dentro del access
        'De la siguiente manera.
        '1)Arracar access
        '2)Hacer click en Herramientas de base de datos
        '3)Click en relaciones
        '4)Hacer doble click en la tabla al que quiere añadir el cascade
        '5)Seleccionar las tablas con la relación y activar la casilla de eliminar/actualizar en cascada
        Dim C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14 As DataColumn
        C5 = almacen.Tables("Provincias").Columns("CodPro")
        C6 = almacen.Tables("Localidades").Columns("CodPro")

        C3 = almacen.Tables("Localidades").Columns("CodLoc")
        C4 = almacen.Tables("Clientes").Columns("CodLoc")

        C1 = almacen.Tables("Clientes").Columns("CodCli")
        C2 = almacen.Tables("Facturas").Columns("CodCli")

        C7 = almacen.Tables("Facturas").Columns("CodFac")
        C8 = almacen.Tables("Lineas_Fac").Columns("CdFac")

        C11 = almacen.Tables("Generos").Columns("CodGenero")
        C12 = almacen.Tables("Peliculas").Columns("CodGenero")

        C9 = almacen.Tables("Peliculas").Columns("CodPelicula")
        C10 = almacen.Tables("Lineas_Fac").Columns("CodPelicula")

        C13 = almacen.Tables("Vendedores").Columns("CodVend")
        C14 = almacen.Tables("Facturas").Columns("CodVend")

        almacen.Relations.Add("ClienteFactura", C1, C2, True)
        almacen.Tables("Clientes").PrimaryKey = New DataColumn() {almacen.Tables("Clientes").Columns("CodCli")}

        almacen.Relations.Add("ClienteLocalidad", C3, C4, True)
        almacen.Tables("Localidades").PrimaryKey = New DataColumn() {almacen.Tables("Localidades").Columns("CodLoc")}

        almacen.Relations.Add("LocalidadProvincia", C5, C6, True)
        almacen.Tables("Provincias").PrimaryKey = New DataColumn() {almacen.Tables("Provincias").Columns("CodPro")}

        almacen.Relations.Add("FacturaLinea", C7, C8, True)
        almacen.Tables("Facturas").PrimaryKey = New DataColumn() {almacen.Tables("Facturas").Columns("CodFac")}

        almacen.Relations.Add("LineaPelicula", C9, C10, True)
        almacen.Tables("Peliculas").PrimaryKey = New DataColumn() {almacen.Tables("Peliculas").Columns("CodPelicula")}

        almacen.Relations.Add("PeliculaGenero", C11, C12, True)
        almacen.Tables("Generos").PrimaryKey = New DataColumn() {almacen.Tables("Generos").Columns("CodGenero")}

        almacen.Relations.Add("FacturaVendedores", C13, C14, True)
        almacen.Tables("Vendedores").PrimaryKey = New DataColumn() {almacen.Tables("Vendedores").Columns("CodVend")}
    End Sub
    'Metodo generar xml
    Public Sub generarXML()
        almacen.WriteXml(ruta & "CopiaSeguridad.xml")
        MsgBox("El xml se creo correctamente")
    End Sub
    'Metodo de cargar el almacen desde el xml creado.
    Public Sub cargarDesdeXML()
        Try
            almacen.ReadXml(ruta & "CopiaSeguridad.xml")
            If Not almacen Is Nothing Then
                MsgBox("Se ha cargado el fichero xml.")
            Else
                MsgBox("No se ha cargado desde el fichero xml o el xml esta vacio.")
            End If
        Catch ex As Exception
            MsgBox("No se ha creado el fichero xml aun.")
        End Try
    End Sub

End Module
