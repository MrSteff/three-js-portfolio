﻿Imports System.Data.OleDb

Public Class visualizar_bdd
    Dim userTables As DataTable
    Dim baseDeDatos As DataTable
    Dim column As DataColumn
    Private backup As New List(Of ListViewItem)
    Dim Sql As String
    Dim item As ListViewItem
    Dim datoFechaInicio As DateTimePicker
    Dim datoFechaFin As DateTimePicker
    Dim metadatos As String
    Dim lastCodCli As Integer
    'Metodo que al cargar la clase se cargue el desplegable que contiene todas las tablas y preparar el listview para relleno de datos.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Reto.conectar()
        'pillar todas las tablas de bdd
        userTables = BDCON.GetOleDbSchemaTable(OleDb.OleDbSchemaGuid.Tables, New String() {Nothing, Nothing, Nothing, Nothing})
        'rellenar combobox con todas las tablas
        For i = 0 To userTables.Rows.Count - 1
            If Not userTables.Rows(i)(2).ToString().Contains("MSys") Then
                datos.Items.Add(userTables.Rows(i)(2).ToString())
            End If
        Next

        Reto.desconectar()
        'preparar vista listview
        ListView1.Clear()
        ListView1.GridLines = True
        ListView1.View = View.Details

    End Sub
    'Al seleccionar una tabla se carga en el listview
    Private Sub datos_DropDownClosed(sender As Object, e As EventArgs) Handles datos.DropDownClosed
        If Not datos.SelectedIndex = -1 Then

            Reto.conectar()
            Sql = "Select * from " & datos.SelectedItem.ToString
            Dim consulta As New OleDbCommand(Sql, BDCON)
            Dim result As OleDbDataReader = consulta.ExecuteReader

            tipo.Items.Clear()
            ListView1.BeginUpdate() 'No cambiar la vista hasta que no se acaban de cargar los datos
            ListView1.Clear()
            metadatos = ""
            'Cargar las columnas y el metadata de la tabla seleccionada y tambien el desplegable de tipos de la tabla.
            For i = 0 To result.FieldCount - 1
                tipo.Items.Add(result.GetName(i))
                ListView1.Columns.Add(result.GetName(i))
                metadatos += result.GetName(i) & ": " & result.GetDataTypeName(i) & vbCrLf
            Next
            'Rellenar el listview con todos los datos sacados.
            Dim x As Integer
            While result.Read
                Try
                    ListView1.Items.Add(result.Item(0))
                    For i = 1 To ListView1.Columns.Count - 1
                        ListView1.Items(x).SubItems.Add(result.Item(i))
                    Next
                Catch ex As Exception

                End Try
                x += 1 'aumentar la posicion del item   |0|subitem|subitem|
                '                                       |x|subitem|subitem|
                'Sacar el ultimo codigo cli para la inserción de datos dummy
                If Integer.Parse(result.Item(0).ToString) > lastCodCli Then
                    lastCodCli = result.Item(0)
                End If
            End While

            ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize) 'formatear la vista para que no se sobrepase a la derecha las columnas.
            ListView1.EndUpdate()
            Reto.desconectar()
        End If

    End Sub
    'Metodo que ordena los datos por la columna seleccionada.
    Private Sub tipo_DropDownClosed(sender As Object, e As EventArgs) Handles tipo.DropDownClosed
        If Not datos.SelectedIndex = -1 Then
            Reto.conectar()
            If tipo.SelectedIndex = -1 Then
                Sql = "Select * from " & datos.SelectedItem.ToString
            Else
                Sql = "Select * from " & datos.SelectedItem.ToString & " order by " & tipo.SelectedItem.ToString
            End If

            Dim consulta As New OleDbCommand(Sql, BDCON)
            Dim result As OleDbDataReader = consulta.ExecuteReader

            ListView1.BeginUpdate()

            ListView1.Clear()

            For i = 0 To result.FieldCount - 1
                ListView1.Columns.Add(result.GetName(i))
            Next

            Dim x As Integer
            While result.Read
                Try
                    ListView1.Items.Add(result.Item(0))
                    For i = 1 To ListView1.Columns.Count - 1
                        ListView1.Items(x).SubItems.Add(result.Item(i))
                    Next
                Catch ex As Exception

                End Try
                x += 1
            End While

            ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
            ListView1.EndUpdate()

            Reto.desconectar()
        End If

    End Sub
    'Metodo para sacar todas las peliculas segun el genero seleccionado.
    Private Sub ComboBox1_DropDownClosed(sender As Object, e As EventArgs) Handles genero.DropDownClosed
        If Not genero.SelectedIndex = -1 Then

            Reto.conectar()
            Sql = "Select * from Peliculas where CodGenero = (Select codGenero from Generos where NomGenero = @nombre)"
            Dim consulta As New OleDbCommand(Sql, BDCON)
            consulta.Parameters.AddWithValue("@nombre", genero.SelectedItem.ToString)
            Dim result As OleDbDataReader = consulta.ExecuteReader

            ListView2.BeginUpdate()
            ListView2.Clear()

            For i = 0 To result.FieldCount - 1
                If Not result.GetName(i) = "CodGenero" Then
                    ListView2.Columns.Add(result.GetName(i))
                Else
                    ListView2.Columns.Add("Genero")
                End If
            Next

            Dim x As Integer
            While result.Read
                Try
                    ListView2.Items.Add(result.Item(0))
                    For i = 1 To ListView2.Columns.Count - 1
                        If Not i = 3 Then
                            ListView2.Items(x).SubItems.Add(result.Item(i))
                        Else
                            ListView2.Items(x).SubItems.Add(genero.SelectedItem.ToString())
                        End If
                    Next
                Catch ex As Exception

                End Try
                x += 1
            End While

            ListView2.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
            ListView2.EndUpdate()
            Reto.desconectar()
        End If
    End Sub
    'Metodo para buscar en toda la tabla en cualquier celda el valor insertado.
    'Faltaria mejoras ya que tarda mucho en una base de datos extensa.
    Private Sub valor_TextChanged(sender As Object, e As EventArgs) Handles valor.TextChanged
        For Each item As ListViewItem In ListView1.Items
            backup.Add(item)
        Next

        If Not valor.Text = "" Then 'Si el textbox no esta vacio se va buscando dentro del listview cualquier celda que contenga el valor

            ListView1.BeginUpdate()

            ListView1.Items.Clear()

            For Each item As ListViewItem In backup
                For i = 0 To item.SubItems.Count - 1
                    Try
                        If item.SubItems(i).Text.ToLower.Contains(valor.Text.ToLower) Then
                            Me.ListView1.Items.Add(item)
                        End If
                    Catch ex As Exception

                    End Try

                Next
            Next

            ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
            ListView1.EndUpdate()
        Else 'Sino vuelve ha cargar el listview con los datos seleccionados previamente.
            If Not datos.SelectedIndex = -1 Then

                Reto.conectar()
                If tipo.SelectedIndex = -1 Then
                    Sql = "Select * from " & datos.SelectedItem.ToString
                Else
                    Sql = "Select * from " & datos.SelectedItem.ToString & " order by " & tipo.SelectedItem.ToString
                End If

                Dim consulta As New OleDbCommand(Sql, BDCON)
                Dim result As OleDbDataReader = consulta.ExecuteReader

                ListView1.BeginUpdate()

                ListView1.Clear()

                For i = 0 To result.FieldCount - 1
                    ListView1.Columns.Add(result.GetName(i))
                Next

                Dim x As Integer
                While result.Read
                    Try
                        ListView1.Items.Add(result.Item(0))
                        For i = 1 To ListView1.Columns.Count - 1
                            ListView1.Items(x).SubItems.Add(result.Item(i))
                        Next
                    Catch ex As Exception

                    End Try
                    x += 1
                End While

                ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
                ListView1.EndUpdate()

                Reto.desconectar()
            End If
        End If
        backup.Clear()
    End Sub
    'Metodo para cargar la vista al pasar a la siguiente ventana.
    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedIndex = 1 Then

            Dim x As Integer = 20

            Datoseleccionado.Controls.Clear()
            Dim label As Label
            Dim dato As TextBox
            Dim botonUpdate1 = New System.Windows.Forms.Button
            Dim botonUpdate2 = New System.Windows.Forms.Button

            botonUpdate1.Visible = True
            botonUpdate2.Visible = True

            Try 'Comprobar que se ha seleccionado alguna fila
                item = ListView1.SelectedItems(0)

                botonUpdate1.Location = New System.Drawing.Point(8, 48)
                botonUpdate1.Name = "update1"
                botonUpdate1.Size = New System.Drawing.Size(131, 23)
                botonUpdate1.TabIndex = 0
                botonUpdate1.Text = "Update sin parametros"
                botonUpdate1.UseVisualStyleBackColor = True

                botonUpdate2.Location = New System.Drawing.Point(7, 96)
                botonUpdate2.Name = "update2"
                botonUpdate2.Size = New System.Drawing.Size(131, 23)
                botonUpdate2.TabIndex = 1
                botonUpdate2.Text = "Update con parametros"
                botonUpdate2.UseVisualStyleBackColor = True

                AddHandler botonUpdate1.Click, AddressOf updateSinParametros
                AddHandler botonUpdate2.Click, AddressOf updateConParametros

                Me.Datoseleccionado.Controls.Add(botonUpdate1)
                Me.Datoseleccionado.Controls.Add(botonUpdate2)

                For i = 0 To item.SubItems.Count - 1
                    label = New System.Windows.Forms.Label()
                    label.AutoSize = True
                    label.Location = New System.Drawing.Point(150, x)
                    x += 2
                    label.Name = "label" & (i + 1)
                    label.Size = New System.Drawing.Size(50, 20)
                    label.TabIndex = i
                    label.Text = ListView1.Columns(i).Text & ": "

                    Me.Datoseleccionado.Controls.Add(label)

                    If item.SubItems(i).Text.ToLower = "false" Or item.SubItems(i).Text.ToLower = "true" Then 'en caso de ser un boolean se crea un combobox con solo 2 opciones.
                        Dim lista As ComboBox = New System.Windows.Forms.ComboBox()
                        lista.FormattingEnabled = True
                        lista.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        x += 40
                        lista.Name = "dato" & (i + 1)
                        lista.Size = New System.Drawing.Size(121, 21)
                        lista.Items.Add("False")
                        lista.Items.Add("True")

                        If item.SubItems(i).Text.ToLower = "false" Then
                            lista.SelectedIndex = 0
                        Else
                            lista.SelectedIndex = 1
                        End If

                        Me.Datoseleccionado.Controls.Add(lista)
                    ElseIf label.Text.ToLower.Contains("fec") Then 'en caso de ser una fecha crearemos un DateTimePicker con formato y con la fecha seleccionada.
                        Dim fecha As DateTimePicker = New System.Windows.Forms.DateTimePicker()

                        fecha.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        fecha.Name = "dato" & (i + 1)
                        fecha.Size = New System.Drawing.Size(200, 20)
                        fecha.Format = DateTimePickerFormat.Custom
                        fecha.CustomFormat = "MM/dd/yyyy"
                        Dim valorFecha As String() = item.SubItems(i).Text.Split("/")
                        fecha.Value = New Date(valorFecha(2), valorFecha(0), valorFecha(1))
                        x += 40
                        Me.Datoseleccionado.Controls.Add(fecha)
                    Else 'En caso de no ser una fecha o un boolean tendra que ser un dato desconocido con lo cual un TextBox comun.
                        dato = New System.Windows.Forms.TextBox()
                        dato.AutoSize = False
                        dato.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        x += 40
                        dato.Name = "dato" & (i + 1)
                        dato.Size = New System.Drawing.Size(ListView1.Columns(i).Width, 20)
                        dato.Text = item.SubItems(i).Text
                        If i = 0 Then
                            dato.Enabled = False
                        End If

                        Me.Datoseleccionado.Controls.Add(dato)
                    End If


                Next
            Catch ex As Exception 'En caso de no seleccionar ningun dato le informaremos al cliente.
                label = New System.Windows.Forms.Label()
                label.AutoSize = True
                label.Location = New System.Drawing.Point(90, 90)
                label.Name = "error"
                label.Size = New System.Drawing.Size(75, 13)
                label.TabIndex = 6
                label.Text = "No se ha seleccionado ningun dato."

                Me.Datoseleccionado.Controls.Add(label)
                botonUpdate1.Visible = False
                botonUpdate2.Visible = False
            End Try
        ElseIf TabControl1.SelectedIndex = 2 Then
            Reto.conectar()
            Sql = "Select NomGenero from Generos"
            Dim consulta As New OleDbCommand(Sql, BDCON)
            Dim result As OleDbDataReader = consulta.ExecuteReader

            While result.Read
                genero.Items.Add(result.Item(0).ToString)
            End While

            Reto.desconectar()
        End If
    End Sub
    'Explicación mas detallada en la opción de ayuda.
    'Metodo que cuenta cuantos registros tiene ese dato especifico, si se selecciona un filtro se hara un contador con ese dato de la fila seleccionada.
    Private Sub contarConParametros(sender As Object, e As EventArgs) Handles ConParametrosToolStripMenuItem.Click
        If datos.SelectedIndex = -1 Then
            MsgBox("No tiene seleccionado ninguna tabla")
        Else
            Try
                Reto.conectar()
                If tipo.SelectedIndex = -1 Then
                    Sql = "Select count(*) from " & datos.SelectedItem.ToString & " where " & tipo.Items(1).ToString & " = @param"
                Else
                    Sql = "Select count(*) from " & datos.SelectedItem.ToString & " where " & tipo.SelectedItem.ToString & " = @param"
                End If

                Dim consulta As New OleDbCommand(Sql, BDCON)

                If tipo.SelectedIndex = -1 And Not ListView1.FocusedItem Is Nothing Then
                    consulta.Parameters.AddWithValue("@param", ListView1.FocusedItem.SubItems(1).Text)
                ElseIf Not ListView1.FocusedItem Is Nothing Then
                    consulta.Parameters.AddWithValue("@param", ListView1.FocusedItem.SubItems(tipo.SelectedIndex).Text)
                End If

                Dim result As OleDbDataReader = consulta.ExecuteReader
                result.Read()

                If tipo.SelectedIndex = -1 Then
                    MsgBox("Se han contado " & result.Item(0).ToString & " elementos en la tabla " & datos.SelectedItem.ToString & " con el dato " & ListView1.FocusedItem.SubItems(1).Text & " de la columna " & tipo.Items(1).ToString)
                Else
                    MsgBox("Se han contado " & result.Item(0).ToString & " elementos en la tabla " & datos.SelectedItem.ToString & " con el dato " & ListView1.FocusedItem.SubItems(tipo.SelectedIndex).Text & " de la columna " & tipo.SelectedItem.ToString)
                End If

                Reto.desconectar()
            Catch ex As Exception
                MsgBox("Datos invalidos en esa fila.")
            End Try

        End If
    End Sub
    'Contar cuantos elementos hay en la tabla actual.
    Private Sub contarSinParametros(sender As Object, e As EventArgs) Handles SinParametrosToolStripMenuItem.Click
        If datos.SelectedIndex = -1 Then
            MsgBox("No tiene seleccionado ninguna tabla")
        Else
            Try
                Reto.conectar()

                Sql = "Select count(*) from " & datos.SelectedItem.ToString

                Dim consulta As New OleDbCommand(Sql, BDCON)
                Dim result As OleDbDataReader = consulta.ExecuteReader

                result.Read()

                MsgBox("Se han contado " & result.Item(0).ToString & " elementos en la tabla " & datos.SelectedItem.ToString)

                Reto.desconectar()
            Catch ex As Exception
                MsgBox("Para buscar con parametros tiene que seleccionar un dato de la tabla.")
            End Try

        End If
    End Sub
    'Metodo para ayudar al cliente.
    Private Sub AyudaToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AyudaToolStripMenuItem1.Click
        MsgBox("Si quiere contar todos los datos de la tabla seleccionada solo hay que seleccionar contar sin parametros. " & vbCrLf & vbCrLf &
               "Si quiere contar por campo especifico tiene que seleccionar el tipo de campo que quiere contar y la linea con el dato que quiere contar, luego solo seleccionar contar con parametros.")
    End Sub
    'Metodo para borrar registros sin parametros
    Private Sub borrarSinParametros(sender As Object, e As EventArgs) Handles SinParametrosToolStripMenuItem1.Click
        If datos.SelectedIndex = -1 Then
            MsgBox("No tiene seleccionado ninguna tabla")
        Else
            Reto.conectar()
            Dim transacion = BDCON.BeginTransaction()
            Try
                If ListView1.MultiSelect = False And Not ListView1.FocusedItem Is Nothing Then 'comprobar que hay alguna fila seleccionada y que no se pueda seleccionar mas de una
                    Sql = "Delete from " & datos.SelectedItem.ToString & " where " & tipo.Items(0).ToString & "=" & ListView1.FocusedItem.SubItems(0).Text
                    Dim consulta As New OleDbCommand(Sql, BDCON)
                    consulta.Transaction = transacion
                    Dim result As Integer
                    Try
                        result = consulta.ExecuteNonQuery
                        transacion.Commit()

                    Catch ex As Exception
                        transacion.Rollback()
                        MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")

                    End Try


                    MsgBox("Se han borrado " & result & " elementos en la tabla " & datos.SelectedItem.ToString & " con el dato " & ListView1.FocusedItem.SubItems(0).Text & " de la columna " & tipo.Items(0).ToString)
                    'Refrescar la tabla al hacer la actualización.
                    If Not datos.SelectedIndex = -1 Then
                        If Not tipo.SelectedIndex = -1 Then
                            tipo_DropDownClosed(sender, e)
                        Else
                            datos_DropDownClosed(sender, e)
                        End If
                    End If
                ElseIf Not ListView1.SelectedItems.Count = 0 Then 'en caso de poder seleccionar mas de una comprobar que hay algo seleccionado ya que haciendo click derecho en los titulos de las columnas puede hacerlo fallar.
                    Dim append As String
                    For Each item As ListViewItem In ListView1.SelectedItems
                        append += item.SubItems(0).Text & ","
                    Next

                    Sql = "Delete from " & datos.SelectedItem.ToString & " where " & tipo.Items(0).ToString & " in (" & append.Substring(0, append.Length - 1) & ")"
                    Dim consulta As New OleDbCommand(Sql, BDCON)
                    consulta.Transaction = transacion
                    Dim result As Integer

                    Try
                        result = consulta.ExecuteNonQuery
                        transacion.Commit()
                        MsgBox("Se han borrado " & result & " elementos en la tabla " & datos.SelectedItem.ToString)
                    Catch ex As Exception
                        transacion.Rollback()
                        MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")
                    End Try

                    'Refrescar la tabla al hacer la actualización.
                    If Not datos.SelectedIndex = -1 Then
                        If Not tipo.SelectedIndex = -1 Then
                            tipo_DropDownClosed(sender, e)
                        Else
                            datos_DropDownClosed(sender, e)
                        End If
                    End If
                Else 'si no hay nada seleccionado se informa al usuario.
                    MsgBox("Se debe seleccionar una fila primero.")
                End If
                Reto.desconectar()
            Catch ex As Exception
                MsgBox("Datos invalidos en esa fila.")
            End Try

        End If
    End Sub
    'Metodo para borrar registros con parametros
    Private Sub borrarConParametros(sender As Object, e As EventArgs) Handles ConParametrosToolStripMenuItem1.Click
        If datos.SelectedIndex = -1 Then
            MsgBox("No tiene seleccionado ninguna tabla")
        Else
            Try
                Reto.conectar()
                Dim transacion = BDCON.BeginTransaction()

                If ListView1.MultiSelect = False Then
                        Sql = "Delete from " & datos.SelectedItem.ToString & " where " & tipo.Items(0).ToString & " = @param"

                        Dim consulta As New OleDbCommand(Sql, BDCON)
                        consulta.Transaction = transacion
                        If Not ListView1.FocusedItem Is Nothing Then
                            consulta.Parameters.AddWithValue("@param", ListView1.FocusedItem.SubItems(0).Text)
                        End If
                        Dim result As Integer

                        Try
                            result = consulta.ExecuteNonQuery
                            transacion.Commit()
                        MsgBox("Se han borrado " & result & " elementos en la tabla " & datos.SelectedItem.ToString & " con el dato " & ListView1.FocusedItem.SubItems(0).Text & " de la columna " & tipo.Items(0).ToString)
                    Catch ex As Exception
                        transacion.Rollback()
                        MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")
                    End Try

                    'Refrescar la tabla al hacer la actualización.
                    If Not datos.SelectedIndex = -1 Then
                            If Not tipo.SelectedIndex = -1 Then
                                tipo_DropDownClosed(sender, e)
                            Else
                                datos_DropDownClosed(sender, e)
                            End If
                        End If
                    ElseIf Not ListView1.SelectedItems.Count = 0 Then
                        Dim append As String
                        Dim param As String
                        Dim contador As Integer = 0
                        For Each item As ListViewItem In ListView1.SelectedItems
                            append += item.SubItems(0).Text & " | "
                            param += "@param" & contador & ","
                            contador += 1
                        Next
                        Dim atributos As String() = append.Substring(0, append.Length - 2).Split("|")

                        Sql = "Delete from " & datos.SelectedItem.ToString & " where " & tipo.Items(0).ToString & " in (" & param.Substring(0, param.Length - 1) & ")"
                        Dim consulta As New OleDbCommand(Sql, BDCON)
                        consulta.Transaction = transacion
                        For i = 0 To atributos.Length - 1
                            consulta.Parameters.AddWithValue("@param" & i, atributos(i))
                        Next

                    Dim result As Integer
                    Try
                        result = consulta.ExecuteNonQuery
                        transacion.Commit()
                        MsgBox("Se han borrado " & result & " elementos en la tabla " & datos.SelectedItem.ToString)
                    Catch ex As Exception
                        transacion.Rollback()
                        MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")
                    End Try

                    'Refrescar la tabla al hacer la actualización.
                    If Not datos.SelectedIndex = -1 Then
                            If Not tipo.SelectedIndex = -1 Then
                                tipo_DropDownClosed(sender, e)
                            Else
                                datos_DropDownClosed(sender, e)
                            End If
                        End If
                    Else
                        MsgBox("Se debe seleccionar una fila primero.")
                    End If

                    Reto.desconectar()
            Catch ex As Exception
                MsgBox("Datos invalidos en esa fila.")
            End Try

        End If
    End Sub
    'Metodo para ayudar al cliente.
    Private Sub AyudaToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AyudaToolStripMenuItem2.Click
        MsgBox("Si la seleccion es de fila unica este borrara solo esa fila " &
                "y esta en seleccion multiple este borrara todos los registros seleccionados." & vbCrLf & vbCrLf &
                "Para Actualizar/Borrar puede usar la opción 'Insert dummy data' de la opcion testeos.")
    End Sub
    'Metodo para actualizar un objeto (sin parametors)
    'Solo cambiara los atributos que se cambiaron.
    Private Sub updateSinParametros(sender As Object, e As EventArgs)
        Reto.conectar()
        Dim transacion = BDCON.BeginTransaction()

        Dim valores As String
        Dim contadocColumna As Integer = 0
        Dim contadorDato As Integer = 0
        Dim comprobacion As Boolean = False
        For Each objeto In TabControl1.TabPages(1).Controls
            If TypeOf objeto Is TextBox Then
                If Not objeto.Text = item.SubItems(0).Text Then
                    If Not objeto.Text.Equals(item.SubItems(contadorDato).Text) Then
                        If Char.IsDigit(objeto.Text) Then
                            valores += ListView1.Columns(contadocColumna).Text & "=" & objeto.Text & ","
                        Else
                            valores += ListView1.Columns(contadocColumna).Text & "=" & "'" & objeto.Text & "',"
                        End If

                        If contadorDato = 1 Then
                            valor.Text = objeto.Text
                        End If

                        comprobacion = True
                    End If
                End If
                contadocColumna += 1
                contadorDato += 1
            End If
        Next
        If comprobacion = True Then
            Sql = "Update " & datos.SelectedItem.ToString & " Set " & valores.Substring(0, valores.Length - 1) & " where " & ListView1.Columns(0).Text & " = " & item.SubItems(0).Text
            Dim consulta As New OleDbCommand(Sql, BDCON)
            consulta.Transaction = transacion
            Dim result As Integer
            Try
                result = consulta.ExecuteNonQuery
                transacion.Commit()
                MsgBox("Se ha hecho " & result & " actualizaciónes en la base de datos.")
            Catch ex As Exception
                transacion.Rollback()
                MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")
            End Try

            datos_DropDownClosed(sender, e)
            valor_TextChanged(sender, e)
            TabControl1.SelectedIndex = 0
        Else
            MsgBox("No se ha modificado ningun campo, 0 actualizaciónes hechas.")
        End If
        Reto.desconectar()
    End Sub
    'Metodo para actualizar un objeto (con parametors)
    'Solo cambiara los atributos que se cambiaron.
    Private Sub updateConParametros(sender As Object, e As EventArgs)
        Reto.conectar()
        Dim transacion = BDCON.BeginTransaction()

        Dim valores As String
        Dim contadocColumna As Integer = 0
        Dim contadorDato As Integer = 0
        Dim comprobacion As Boolean = False
        Dim posicioncambio(item.SubItems.Count - 1) As TextBox
        For Each objeto In TabControl1.TabPages(1).Controls
            If TypeOf objeto Is TextBox Then
                If Not objeto.Text = item.SubItems(0).Text Then
                    If Not objeto.Text.Equals(item.SubItems(contadorDato).Text) Then
                        valores += ListView1.Columns(contadocColumna).Text & "=@param" & (contadocColumna - 1) & ","
                        If contadorDato = 1 Then
                            valor.Text = objeto.Text
                        End If
                        posicioncambio(contadocColumna - 1) = objeto

                        comprobacion = True
                    End If
                End If
                contadocColumna += 1
                contadorDato += 1
            End If
        Next
        If comprobacion = True Then
            Sql = "Update " & datos.SelectedItem.ToString & " Set " & valores.Substring(0, valores.Length - 1) & " where " & ListView1.Columns(0).Text & "=@codigo"
            Dim consulta As New OleDbCommand(Sql, BDCON)
            For i = 0 To UBound(posicioncambio)
                If Not posicioncambio(i) Is Nothing Then
                    consulta.Parameters.AddWithValue("@param" & i, posicioncambio(i).Text)
                End If
            Next
            consulta.Parameters.AddWithValue("@codigo", item.SubItems(0).Text)
            consulta.Transaction = transacion
            Dim result As Integer
            Try
                result = consulta.ExecuteNonQuery
                transacion.Commit()
                MsgBox("Se ha hecho " & result & " actualizaciónes en la base de datos.")
            Catch ex As Exception
                transacion.Rollback()
                MsgBox("No se ha podido realizar esta acción, los datos han sido restaurados en la bdd.")
            End Try

            datos_DropDownClosed(sender, e)
            valor_TextChanged(sender, e)
            TabControl1.SelectedIndex = 0
        Else
            MsgBox("No se ha modificado ningun campo, 0 actualizaciónes hechas.")
        End If

        Reto.desconectar()
    End Sub
    'Metodo para cambiar de modo de seleccion a poder solo seleccionar una celda.
    Private Sub CeldaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CeldaToolStripMenuItem.Click
        ListView1.FullRowSelect = False
    End Sub
    'Metodo para cambiar de modo de seleccion a poder seleccionar una fila entera.
    Private Sub FilaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FilaToolStripMenuItem.Click
        ListView1.FullRowSelect = True
    End Sub
    'Metodo para poder seleccionar mas de una fila/celda.
    Private Sub VariasFilasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VariasFilasToolStripMenuItem.Click
        If ListView1.MultiSelect = True Then
            ListView1.MultiSelect = False
        Else
            ListView1.MultiSelect = True
        End If
    End Sub
    'Metodo para ir a la clase de insertar un objeto de modo conectado.
    Private Sub InsertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InsertToolStripMenuItem.Click
        insertar.Show()
        Me.Close()
    End Sub
    'Metodo para ir a la clase de visualizar los datos en modo no conectado.
    Private Sub AdaptadorToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles AdaptadorToolStripMenuItem4.Click
        visualizar_adaptador.Show()
        Me.Close()
    End Sub
    'Metodo para habilitar la busqueda entre 2 fechas.
    Private Sub BusquedaEntreFechasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BusquedaEntreFechasToolStripMenuItem.Click
        ListView1.Height = 300
        Dim mover As Point = New Point(8, 93)
        ListView1.Location = mover

        Dim labelFechaMenor As Label
        Dim labelFechaMayor As Label

        labelFechaMenor = New System.Windows.Forms.Label()
        labelFechaMenor.AutoSize = True
        labelFechaMenor.Location = New System.Drawing.Point(50, 50)
        labelFechaMenor.Name = "fechaMenor"
        labelFechaMenor.Size = New System.Drawing.Size(50, 20)
        labelFechaMenor.Text = "Desde: "

        datoFechaInicio = New System.Windows.Forms.DateTimePicker()
        datoFechaInicio.AutoSize = False
        datoFechaInicio.Location = New System.Drawing.Point(labelFechaMenor.Width + 60, 47)
        datoFechaInicio.Name = "FechaInicio"
        datoFechaInicio.Size = New System.Drawing.Size(200, 20)
        datoFechaInicio.Format = DateTimePickerFormat.Custom
        datoFechaInicio.CustomFormat = "MM/dd/yyyy"

        labelFechaMayor = New System.Windows.Forms.Label()
        labelFechaMayor.AutoSize = True
        labelFechaMayor.Location = New System.Drawing.Point(labelFechaMenor.Width + datoFechaInicio.Width + 70, 50)
        labelFechaMayor.Name = "fechaMenor"
        labelFechaMayor.Size = New System.Drawing.Size(50, 20)
        labelFechaMayor.Text = "Hasta: "

        datoFechaFin = New System.Windows.Forms.DateTimePicker()
        datoFechaFin.AutoSize = False
        datoFechaFin.Location = New System.Drawing.Point(labelFechaMenor.Width + datoFechaInicio.Width + labelFechaMayor.Width + 70, 47)
        datoFechaFin.Name = "FechaFin"
        datoFechaFin.Size = New System.Drawing.Size(200, 20)
        datoFechaFin.Format = DateTimePickerFormat.Custom
        datoFechaFin.CustomFormat = "MM/dd/yyyy"

        Me.VisualisarDatos.Controls.Add(labelFechaMenor)
        Me.VisualisarDatos.Controls.Add(datoFechaInicio)
        Me.VisualisarDatos.Controls.Add(labelFechaMayor)
        Me.VisualisarDatos.Controls.Add(datoFechaFin)

        AddHandler datoFechaInicio.CloseUp, AddressOf filtroPorFechas
        AddHandler datoFechaFin.CloseUp, AddressOf filtroPorFechas
    End Sub
    'Metodo para buscar entre 2 fechas.
    Public Sub filtroPorFechas()

        If Not datos.SelectedIndex = -1 Then
            If Not tipo.SelectedIndex = -1 Then
                Reto.conectar()
                Sql = "Select * from " & datos.SelectedItem.ToString & " where " & tipo.SelectedItem.ToString & " BETWEEN @fecha1 and @fecha2"
                Dim consulta As New OleDbCommand(Sql, BDCON)
                consulta.Parameters.AddWithValue("@fecha1", datoFechaInicio.Value.ToShortDateString.ToString)
                consulta.Parameters.AddWithValue("@fecha2", datoFechaFin.Value.ToShortDateString.ToString)
                Dim result As OleDbDataReader = consulta.ExecuteReader
                ListView1.BeginUpdate()
                ListView1.Clear()

                For i = 0 To result.FieldCount - 1
                    ListView1.Columns.Add(result.GetName(i))
                Next

                Dim x As Integer
                While result.Read()
                    Try
                        ListView1.Items.Add(result.Item(0).ToString)
                        For i = 1 To ListView1.Columns.Count - 1
                            ListView1.Items(x).SubItems.Add(result.Item(i).ToString)
                        Next
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                    x += 1
                End While

                ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
                ListView1.EndUpdate()
                Reto.desconectar()
            Else
                MsgBox("Tiene que seleccionar la fecha en ordenar por.")
            End If
        Else
            MsgBox("Tiene Que seleccionar una tabla.")
        End If
    End Sub
    'Metodo para ver los metadatos de la tabla seleccionada.
    Private Sub VisualizarClientesMsgboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VisualizarClientesMsgboxToolStripMenuItem.Click
        If Not datos.SelectedIndex = -1 Then
            MsgBox(metadatos)
        Else
            MsgBox("Tiene que seleccionar una tabla.")
        End If
    End Sub
    'Metodo para mostrar todos los clientes de 25 en 25 independientemente de que tabla tengas activa.
    Private Sub ClientesMsgToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClientesMsgToolStripMenuItem.Click
        Reto.conectar()
        Sql = "Select NombCli from Clientes"
        Dim consulta As New OleDbCommand(Sql, BDCON)
        Dim result As OleDbDataReader = consulta.ExecuteReader
        Dim stringBuilder As String
        Dim contador As Integer = 1
        While result.Read
            stringBuilder += contador & ") " & result.Item(0).ToString & vbCrLf
            contador += 1
            If (contador Mod 26) = 0 Then
                MsgBox(stringBuilder)
                stringBuilder = ""
            End If
        End While
        If Not stringBuilder = "" Then
            MsgBox(stringBuilder)
            stringBuilder = ""
        End If

        Reto.desconectar()
    End Sub
    'Metodo para insertar datos que no estan vinculados a otras tablas y se pueden modificar/borrar facilmente sin necesidad de relacion a otras tablas.
    Private Sub InsertarDummyDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InsertarDummyDataToolStripMenuItem.Click
        Reto.conectar()
        Dim consulta As OleDbCommand

        If datos.SelectedIndex = 0 Then
            For i = 0 To 10
                lastCodCli += 1
                Sql = "Insert into Clientes (CodCli,NombCli) values(" & lastCodCli & ", 'Tester" & lastCodCli & "')"
                consulta = New OleDbCommand(Sql, BDCON)
                Dim result As Integer = consulta.ExecuteNonQuery
            Next
        End If
        Reto.desconectar()
        datos_DropDownClosed(sender, e)
    End Sub
    'Metodo para restablecer la vista por defecto.
    Private Sub QuitarBusquedaEntreFechasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuitarBusquedaEntreFechasToolStripMenuItem.Click
        ListView1.Height = 350
        ListView1.Location = New Point(8, 43)
    End Sub
End Class
'Optimización: al borrar quitar las filas en vez de volver a cargar todos los datos.