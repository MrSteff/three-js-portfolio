﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class visualizar_bdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ConsultasListView = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ContarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConParametrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SinParametrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SinParametrosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConParametrosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusquedaAvanzadaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusquedaEntreFechasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitarBusquedaEntreFechasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeleccionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FilaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CeldaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VariasFilasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VisualizarClientesMsgboxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientesMsgToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TesteoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarDummyDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.VisualisarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdaptadorToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.VisualisarDatos = New System.Windows.Forms.TabPage()
        Me.valor = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.datos = New System.Windows.Forms.ComboBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tipo = New System.Windows.Forms.ComboBox()
        Me.Datoseleccionado = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.genero = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ConsultasListView.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.VisualisarDatos.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ConsultasListView
        '
        Me.ConsultasListView.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContarToolStripMenuItem, Me.BorrarToolStripMenuItem, Me.BusquedaAvanzadaToolStripMenuItem, Me.SeleccionToolStripMenuItem, Me.VisualizarClientesMsgboxToolStripMenuItem, Me.ClientesMsgToolStripMenuItem, Me.TesteoToolStripMenuItem})
        Me.ConsultasListView.Name = "ContextMenuStrip1"
        Me.ConsultasListView.Size = New System.Drawing.Size(181, 158)
        '
        'ContarToolStripMenuItem
        '
        Me.ContarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConParametrosToolStripMenuItem, Me.SinParametrosToolStripMenuItem, Me.AyudaToolStripMenuItem1})
        Me.ContarToolStripMenuItem.Name = "ContarToolStripMenuItem"
        Me.ContarToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ContarToolStripMenuItem.Text = "Contar"
        '
        'ConParametrosToolStripMenuItem
        '
        Me.ConParametrosToolStripMenuItem.Name = "ConParametrosToolStripMenuItem"
        Me.ConParametrosToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.ConParametrosToolStripMenuItem.Text = "Con parametros"
        '
        'SinParametrosToolStripMenuItem
        '
        Me.SinParametrosToolStripMenuItem.Name = "SinParametrosToolStripMenuItem"
        Me.SinParametrosToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.SinParametrosToolStripMenuItem.Text = "Sin parametros"
        '
        'AyudaToolStripMenuItem1
        '
        Me.AyudaToolStripMenuItem1.Name = "AyudaToolStripMenuItem1"
        Me.AyudaToolStripMenuItem1.Size = New System.Drawing.Size(159, 22)
        Me.AyudaToolStripMenuItem1.Text = "Ayuda"
        '
        'BorrarToolStripMenuItem
        '
        Me.BorrarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SinParametrosToolStripMenuItem1, Me.ConParametrosToolStripMenuItem1, Me.AyudaToolStripMenuItem2})
        Me.BorrarToolStripMenuItem.Name = "BorrarToolStripMenuItem"
        Me.BorrarToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.BorrarToolStripMenuItem.Text = "Borrar"
        '
        'SinParametrosToolStripMenuItem1
        '
        Me.SinParametrosToolStripMenuItem1.Name = "SinParametrosToolStripMenuItem1"
        Me.SinParametrosToolStripMenuItem1.Size = New System.Drawing.Size(159, 22)
        Me.SinParametrosToolStripMenuItem1.Text = "Sin parametros"
        '
        'ConParametrosToolStripMenuItem1
        '
        Me.ConParametrosToolStripMenuItem1.Name = "ConParametrosToolStripMenuItem1"
        Me.ConParametrosToolStripMenuItem1.Size = New System.Drawing.Size(159, 22)
        Me.ConParametrosToolStripMenuItem1.Text = "Con parametros"
        '
        'AyudaToolStripMenuItem2
        '
        Me.AyudaToolStripMenuItem2.Name = "AyudaToolStripMenuItem2"
        Me.AyudaToolStripMenuItem2.Size = New System.Drawing.Size(159, 22)
        Me.AyudaToolStripMenuItem2.Text = "Ayuda"
        '
        'BusquedaAvanzadaToolStripMenuItem
        '
        Me.BusquedaAvanzadaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BusquedaEntreFechasToolStripMenuItem, Me.QuitarBusquedaEntreFechasToolStripMenuItem})
        Me.BusquedaAvanzadaToolStripMenuItem.Name = "BusquedaAvanzadaToolStripMenuItem"
        Me.BusquedaAvanzadaToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.BusquedaAvanzadaToolStripMenuItem.Text = "Busqueda Avanzada"
        '
        'BusquedaEntreFechasToolStripMenuItem
        '
        Me.BusquedaEntreFechasToolStripMenuItem.Name = "BusquedaEntreFechasToolStripMenuItem"
        Me.BusquedaEntreFechasToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.BusquedaEntreFechasToolStripMenuItem.Text = "Busqueda entre fechas"
        '
        'QuitarBusquedaEntreFechasToolStripMenuItem
        '
        Me.QuitarBusquedaEntreFechasToolStripMenuItem.Name = "QuitarBusquedaEntreFechasToolStripMenuItem"
        Me.QuitarBusquedaEntreFechasToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.QuitarBusquedaEntreFechasToolStripMenuItem.Text = "Quitar busqueda entre fechas"
        '
        'SeleccionToolStripMenuItem
        '
        Me.SeleccionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilaToolStripMenuItem, Me.CeldaToolStripMenuItem, Me.VariasFilasToolStripMenuItem})
        Me.SeleccionToolStripMenuItem.Name = "SeleccionToolStripMenuItem"
        Me.SeleccionToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SeleccionToolStripMenuItem.Text = "Seleccion"
        '
        'FilaToolStripMenuItem
        '
        Me.FilaToolStripMenuItem.Name = "FilaToolStripMenuItem"
        Me.FilaToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.FilaToolStripMenuItem.Text = "Fila"
        '
        'CeldaToolStripMenuItem
        '
        Me.CeldaToolStripMenuItem.Name = "CeldaToolStripMenuItem"
        Me.CeldaToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.CeldaToolStripMenuItem.Text = "Celda"
        '
        'VariasFilasToolStripMenuItem
        '
        Me.VariasFilasToolStripMenuItem.Name = "VariasFilasToolStripMenuItem"
        Me.VariasFilasToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.VariasFilasToolStripMenuItem.Text = "Varias Filas"
        '
        'VisualizarClientesMsgboxToolStripMenuItem
        '
        Me.VisualizarClientesMsgboxToolStripMenuItem.Name = "VisualizarClientesMsgboxToolStripMenuItem"
        Me.VisualizarClientesMsgboxToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.VisualizarClientesMsgboxToolStripMenuItem.Text = "Metadata"
        '
        'ClientesMsgToolStripMenuItem
        '
        Me.ClientesMsgToolStripMenuItem.Name = "ClientesMsgToolStripMenuItem"
        Me.ClientesMsgToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ClientesMsgToolStripMenuItem.Text = "Clientes Msg"
        '
        'TesteoToolStripMenuItem
        '
        Me.TesteoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InsertarDummyDataToolStripMenuItem})
        Me.TesteoToolStripMenuItem.Name = "TesteoToolStripMenuItem"
        Me.TesteoToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TesteoToolStripMenuItem.Text = "Testeo"
        '
        'InsertarDummyDataToolStripMenuItem
        '
        Me.InsertarDummyDataToolStripMenuItem.Name = "InsertarDummyDataToolStripMenuItem"
        Me.InsertarDummyDataToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.InsertarDummyDataToolStripMenuItem.Text = "Insertar Dummy data"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisualisarToolStripMenuItem, Me.InsertToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'VisualisarToolStripMenuItem
        '
        Me.VisualisarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdaptadorToolStripMenuItem4})
        Me.VisualisarToolStripMenuItem.Name = "VisualisarToolStripMenuItem"
        Me.VisualisarToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.VisualisarToolStripMenuItem.Text = "Visualisar"
        '
        'AdaptadorToolStripMenuItem4
        '
        Me.AdaptadorToolStripMenuItem4.Name = "AdaptadorToolStripMenuItem4"
        Me.AdaptadorToolStripMenuItem4.Size = New System.Drawing.Size(130, 22)
        Me.AdaptadorToolStripMenuItem4.Text = "Adaptador"
        '
        'InsertToolStripMenuItem
        '
        Me.InsertToolStripMenuItem.Name = "InsertToolStripMenuItem"
        Me.InsertToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.InsertToolStripMenuItem.Text = "Insert"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.VisualisarDatos)
        Me.TabControl1.Controls.Add(Me.Datoseleccionado)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(0, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(800, 425)
        Me.TabControl1.TabIndex = 2
        '
        'VisualisarDatos
        '
        Me.VisualisarDatos.Controls.Add(Me.valor)
        Me.VisualisarDatos.Controls.Add(Me.Label1)
        Me.VisualisarDatos.Controls.Add(Me.datos)
        Me.VisualisarDatos.Controls.Add(Me.ListView1)
        Me.VisualisarDatos.Controls.Add(Me.Label3)
        Me.VisualisarDatos.Controls.Add(Me.Label2)
        Me.VisualisarDatos.Controls.Add(Me.tipo)
        Me.VisualisarDatos.Location = New System.Drawing.Point(4, 22)
        Me.VisualisarDatos.Name = "VisualisarDatos"
        Me.VisualisarDatos.Padding = New System.Windows.Forms.Padding(3)
        Me.VisualisarDatos.Size = New System.Drawing.Size(792, 399)
        Me.VisualisarDatos.TabIndex = 0
        Me.VisualisarDatos.Text = "Visualizar Datos"
        Me.VisualisarDatos.UseVisualStyleBackColor = True
        '
        'valor
        '
        Me.valor.Location = New System.Drawing.Point(505, 6)
        Me.valor.Name = "valor"
        Me.valor.Size = New System.Drawing.Size(279, 20)
        Me.valor.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Tabla"
        '
        'datos
        '
        Me.datos.FormattingEnabled = True
        Me.datos.Location = New System.Drawing.Point(40, 6)
        Me.datos.Name = "datos"
        Me.datos.Size = New System.Drawing.Size(121, 21)
        Me.datos.TabIndex = 5
        '
        'ListView1
        '
        Me.ListView1.ContextMenuStrip = Me.ConsultasListView
        Me.ListView1.FullRowSelect = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(8, 43)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(776, 350)
        Me.ListView1.TabIndex = 4
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(363, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Buscar en cualquier campo"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(167, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Ordenar por"
        '
        'tipo
        '
        Me.tipo.FormattingEnabled = True
        Me.tipo.Location = New System.Drawing.Point(236, 6)
        Me.tipo.Name = "tipo"
        Me.tipo.Size = New System.Drawing.Size(121, 21)
        Me.tipo.TabIndex = 0
        '
        'Datoseleccionado
        '
        Me.Datoseleccionado.Location = New System.Drawing.Point(4, 22)
        Me.Datoseleccionado.Name = "Datoseleccionado"
        Me.Datoseleccionado.Padding = New System.Windows.Forms.Padding(3)
        Me.Datoseleccionado.Size = New System.Drawing.Size(792, 399)
        Me.Datoseleccionado.TabIndex = 1
        Me.Datoseleccionado.Text = "Dato seleccionado"
        Me.Datoseleccionado.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ListView2)
        Me.TabPage1.Controls.Add(Me.genero)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(792, 399)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Buscar por Genero"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ListView2
        '
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(6, 51)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(778, 342)
        Me.ListView2.TabIndex = 2
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'genero
        '
        Me.genero.FormattingEnabled = True
        Me.genero.Location = New System.Drawing.Point(73, 24)
        Me.genero.Name = "genero"
        Me.genero.Size = New System.Drawing.Size(121, 21)
        Me.genero.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Genero"
        '
        'visualizar_bdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "visualizar_bdd"
        Me.Text = "Conectado a Base de datos"
        Me.ConsultasListView.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.VisualisarDatos.ResumeLayout(False)
        Me.VisualisarDatos.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ConsultasListView As ContextMenuStrip
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents InsertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents VisualisarDatos As TabPage
    Friend WithEvents Label1 As Label
    Friend WithEvents datos As ComboBox
    Friend WithEvents ListView1 As ListView
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tipo As ComboBox
    Friend WithEvents valor As TextBox
    Friend WithEvents Datoseleccionado As TabPage
    Friend WithEvents VisualisarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdaptadorToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ContarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConParametrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SinParametrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BusquedaAvanzadaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BusquedaEntreFechasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VisualizarClientesMsgboxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SeleccionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FilaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CeldaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BorrarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SinParametrosToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ConParametrosToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents VariasFilasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QuitarBusquedaEntreFechasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientesMsgToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents ListView2 As ListView
    Friend WithEvents genero As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TesteoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InsertarDummyDataToolStripMenuItem As ToolStripMenuItem
End Class
