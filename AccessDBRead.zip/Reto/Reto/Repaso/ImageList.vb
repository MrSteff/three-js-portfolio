﻿Public Class ImageList
    Private Sub ToolBar1_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        If e.Button.Tag = "inicio" Then
            MsgBox("hola")
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i = 1 To 5
            Dim nombre As String = "Alumno" & i
            Me.ListView1.Items.Add(nombre)
            Me.ListView1.Items(i - 1).SubItems.Add("Dam-2")
            Me.ListView1.Items(i - 1).SubItems.Add(i)
        Next

    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        TextBox1.Text = ListView1.FocusedItem.Text
        TextBox2.Text = ListView1.FocusedItem.SubItems(1).Text
        TextBox3.Text = ListView1.FocusedItem.SubItems(2).Text
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        Process.Start("https://www.google.com")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        indice.Show()
        Me.Close()
    End Sub
End Class