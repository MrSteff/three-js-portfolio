﻿Public Class indice
    'Metodo de ir hasta la clase de visualizar la bdd en modo conectado.
    Private Sub BaseDeDatosToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles BaseDeDatosToolStripMenuItem4.Click
        visualizar_bdd.Show()
        Me.Close()
    End Sub
    'Metodo para ir a la clase de insertar un objeto en la bdd en modo conectado
    Private Sub InsertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InsertToolStripMenuItem.Click
        insertar.Show()
        Me.Close()
    End Sub
    'Metodo para ir a la clase de visualizar la bdd en modo no conectado.
    Private Sub AdaptadorToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles AdaptadorToolStripMenuItem4.Click
        visualizar_adaptador.Show()
        Me.Close()
    End Sub
    'Cargar el almacen.
    Private Sub indice_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BDD.cargarAlmacen()
    End Sub
    'Metodo para que cuando haces click en el vinculo te muestre el gmail con la cuenta del creador del proyecto.
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim url As String = "https://mail.google.com/mail/u/0/?view=cm&fs=1&to=galavans80@gmail.com&su=Hola&body=BugReport?&tf=1"
        Process.Start(url)
    End Sub


End Class