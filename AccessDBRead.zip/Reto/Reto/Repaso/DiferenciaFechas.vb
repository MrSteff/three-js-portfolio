﻿Public Class DiferenciaFechas
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        Label3.Text = Math.Round(Now.Subtract(DateTimePicker1.Value).Days)
        Label2.Text = Math.Round(Now.Subtract(DateTimePicker1.Value).Days / 12)
        Label1.Text = Math.Round(Now.Subtract(DateTimePicker1.Value).Days / 365)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        indice.Show()
        Me.Close()
    End Sub

    Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateChanged
        Label8.Text = e.Start.ToString
        Label7.Text = e.End.ToString
    End Sub
End Class