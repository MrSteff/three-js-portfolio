﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ImageList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ImageList))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Nombre2 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Notas2 = New System.Windows.Forms.TabPage()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Nombre = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Curso = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Nota = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.inicio = New System.Windows.Forms.ToolBarButton()
        Me.archivos = New System.Windows.Forms.ToolBarButton()
        Me.imprimir = New System.Windows.Forms.ToolBarButton()
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.Nombre2.SuspendLayout()
        Me.Notas2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Nombre2)
        Me.TabControl1.Controls.Add(Me.Notas2)
        Me.TabControl1.ImageList = Me.ImageList1
        Me.TabControl1.Location = New System.Drawing.Point(12, 258)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(200, 101)
        Me.TabControl1.TabIndex = 13
        '
        'Nombre2
        '
        Me.Nombre2.Controls.Add(Me.Label1)
        Me.Nombre2.ImageIndex = 3
        Me.Nombre2.Location = New System.Drawing.Point(4, 23)
        Me.Nombre2.Name = "Nombre2"
        Me.Nombre2.Padding = New System.Windows.Forms.Padding(3)
        Me.Nombre2.Size = New System.Drawing.Size(192, 74)
        Me.Nombre2.TabIndex = 0
        Me.Nombre2.Text = "Nombre"
        Me.Nombre2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Label1"
        '
        'Notas2
        '
        Me.Notas2.Controls.Add(Me.Label3)
        Me.Notas2.Controls.Add(Me.Label2)
        Me.Notas2.ImageIndex = 9
        Me.Notas2.Location = New System.Drawing.Point(4, 23)
        Me.Notas2.Name = "Notas2"
        Me.Notas2.Padding = New System.Windows.Forms.Padding(3)
        Me.Notas2.Size = New System.Drawing.Size(192, 74)
        Me.Notas2.TabIndex = 1
        Me.Notas2.Text = "Notas2"
        Me.Notas2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(150, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Label3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Label2"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "and_icon.png")
        Me.ImageList1.Images.SetKeyName(1, "beetailer-icon.png")
        Me.ImageList1.Images.SetKeyName(2, "bitnami.ico")
        Me.ImageList1.Images.SetKeyName(3, "cdb.ico")
        Me.ImageList1.Images.SetKeyName(4, "certificate.ico")
        Me.ImageList1.Images.SetKeyName(5, "error.ico")
        Me.ImageList1.Images.SetKeyName(6, "favicon.ico")
        Me.ImageList1.Images.SetKeyName(7, "folder.ico")
        Me.ImageList1.Images.SetKeyName(8, "green.ico")
        Me.ImageList1.Images.SetKeyName(9, "or_icon.png")
        Me.ImageList1.Images.SetKeyName(10, "pdf-icon.png")
        Me.ImageList1.Images.SetKeyName(11, "php.ico")
        Me.ImageList1.Images.SetKeyName(12, "red.ico")
        Me.ImageList1.Images.SetKeyName(13, "social-icons-large@2x.png")
        Me.ImageList1.Images.SetKeyName(14, "stack-icons.png")
        Me.ImageList1.Images.SetKeyName(15, "sugaroutfitters-icon.png")
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(467, 258)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 12
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(467, 184)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 11
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(467, 111)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 10
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Nombre, Me.Curso, Me.Nota})
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(11, 67)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(372, 167)
        Me.ListView1.TabIndex = 9
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'Nombre
        '
        Me.Nombre.Tag = "Nombre"
        Me.Nombre.Text = "Nombre"
        '
        'Curso
        '
        Me.Curso.Tag = "Curso"
        Me.Curso.Text = "Curso"
        '
        'Nota
        '
        Me.Nota.Tag = "Nota"
        Me.Nota.Text = "Nota"
        '
        'ToolBar1
        '
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.inicio, Me.archivos, Me.imprimir})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.ImageList1
        Me.ToolBar1.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(800, 50)
        Me.ToolBar1.TabIndex = 8
        '
        'inicio
        '
        Me.inicio.ImageIndex = 0
        Me.inicio.Name = "inicio"
        Me.inicio.Tag = "inicio"
        Me.inicio.Text = "inicio"
        '
        'archivos
        '
        Me.archivos.ImageIndex = 7
        Me.archivos.Name = "archivos"
        Me.archivos.Text = "archivos"
        '
        'imprimir
        '
        Me.imprimir.ImageIndex = 12
        Me.imprimir.Name = "imprimir"
        Me.imprimir.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton
        Me.imprimir.Text = "imprimir"
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.Text = "OpcionPapel"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "OpcionPDF"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.Text = "OpcionJPG"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(337, 404)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Volver"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.ToolBar1)
        Me.Name = "Form1"
        Me.Text = "Que guay este :v"
        Me.TabControl1.ResumeLayout(False)
        Me.Nombre2.ResumeLayout(False)
        Me.Nombre2.PerformLayout()
        Me.Notas2.ResumeLayout(False)
        Me.Notas2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Nombre2 As TabPage
    Friend WithEvents Label1 As Label
    Friend WithEvents Notas2 As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ListView1 As ListView
    Friend WithEvents Nombre As ColumnHeader
    Friend WithEvents Curso As ColumnHeader
    Friend WithEvents Nota As ColumnHeader
    Friend WithEvents ToolBar1 As ToolBar
    Friend WithEvents inicio As ToolBarButton
    Friend WithEvents archivos As ToolBarButton
    Friend WithEvents imprimir As ToolBarButton
    Friend WithEvents ImageList1 As Windows.Forms.ImageList
    Friend WithEvents ContextMenu1 As ContextMenu
    Friend WithEvents MenuItem1 As MenuItem
    Friend WithEvents MenuItem2 As MenuItem
    Friend WithEvents MenuItem3 As MenuItem
    Friend WithEvents Button1 As Button
End Class
