﻿Imports System.Data.OleDb

Public Class insertar
    Dim userTables As DataTable
    Dim Sql As String
    'Cargar todas las tablas en el desplegable.
    Private Sub insertar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reto.conectar()
        'recoger las tablas
        userTables = BDCON.GetOleDbSchemaTable(OleDb.OleDbSchemaGuid.Tables, New String() {Nothing, Nothing, Nothing, Nothing})
        'rellenar el desplegable
        For i = 0 To userTables.Rows.Count - 1
            If Not userTables.Rows(i)(2).ToString().Contains("MSys") Then
                datos.Items.Add(userTables.Rows(i)(2).ToString())
            End If
        Next

        Reto.desconectar()
    End Sub
    'Al cerrar el combobox crear las etiquetas y textbox que hace falta para la inserción de datos.
    Private Sub datos_DropDownClosed(sender As Object, e As EventArgs) Handles datos.DropDownClosed
        Reto.conectar()
        Sql = "Select top 1 * from " & datos.SelectedItem.ToString      'se hace una consulta para sacar los nombres de las columnas 
        Dim consulta As New OleDbCommand(Sql, BDCON)
        Dim result As OleDbDataReader = consulta.ExecuteReader
        Dim label As Label
        Dim dato As TextBox
        Dim x As Integer = 20
        Panel1.Controls.Clear()

        For i = 0 To result.FieldCount - 1
            label = New System.Windows.Forms.Label()
            label.AutoSize = True
            label.Location = New System.Drawing.Point(120, x)
            x += 5
            label.Name = "label" & (i + 1)
            label.Size = New System.Drawing.Size(50, 20)
            label.Text = result.GetName(i)
            Me.Panel1.Controls.Add(label)

            Try
                If result.GetDataTypeName(i) = "DBTYPE_DATE" Then
                    Dim fecha As DateTimePicker = New System.Windows.Forms.DateTimePicker()

                    fecha.Location = New System.Drawing.Point(label.Width + 180, x - 5)
                    fecha.Name = "dato" & (i + 1)
                    fecha.Size = New System.Drawing.Size(200, 20)
                    fecha.Format = DateTimePickerFormat.Custom
                    fecha.CustomFormat = "MM/dd/yyyy"
                    x += 40
                    Me.Panel1.Controls.Add(fecha)
                ElseIf result.GetDataTypeName(i) = "DBTYPE_BOOL" Then
                    Dim lista As ComboBox = New System.Windows.Forms.ComboBox()
                    lista.FormattingEnabled = True
                    lista.Location = New System.Drawing.Point(label.Width + 180, x - 5)
                    x += 40
                    lista.Name = "dato" & (i + 1)
                    lista.Size = New System.Drawing.Size(121, 21)
                    lista.Items.Add("False")
                    lista.Items.Add("True")
                    lista.SelectedIndex = 0
                    Me.Panel1.Controls.Add(lista)
                Else
                    dato = New System.Windows.Forms.TextBox()
                    dato.AutoSize = False
                    dato.Location = New System.Drawing.Point(label.Width + 180, x - 5)
                    x += 40
                    dato.Name = "dato" & (i + 1)
                    dato.Size = New System.Drawing.Size(120, 20)
                    dato.Text = ""
                    Me.Panel1.Controls.Add(dato)
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Next
        Reto.desconectar()
        Button1.Visible = True
        Button2.Visible = True
    End Sub
    'Metodo para insertar en la base de datos los datos sin parametros.
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Reto.conectar()
        Dim transaccion = BDCON.BeginTransaction
        Try
            Dim valores As String
            For Each objeto In Panel1.Controls
                If TypeOf objeto Is TextBox Then
                    If objeto.Name.ToString.ToLower.Contains("dato") Then
                        If Char.IsDigit(objeto.Text) Then
                            valores += objeto.Text & ","
                        Else
                            valores += "'" & objeto.Text & "',"
                        End If

                    End If
                End If
            Next
            Sql = "Insert into " & datos.SelectedItem.ToString & " values(" & valores.Substring(0, valores.Length - 1) & ")"
            Dim consulta As New OleDbCommand(Sql, BDCON)
            Dim result As Integer = consulta.ExecuteNonQuery

            MsgBox("Se ha hecho " & result & " inserciones a la base de datos.")
        Catch ex As Exception
            transaccion.Rollback()
        End Try
        Reto.desconectar()
    End Sub
    'Metodo para insertar en la base de datos los datos con parametros.
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Reto.conectar()
        Dim transaccion = BDCON.BeginTransaction
        Try
            Dim valores As String
            For Each objeto In Panel1.Controls

                If objeto.Name.ToString.ToLower.Contains("dato") Then
                    If Char.IsDigit(objeto.Text) Then
                        valores += objeto.Text & "|"
                    Else
                        valores += "'" & objeto.Text & "'|"
                    End If

                End If

            Next

            Dim parametros As String
            For i = 0 To (Panel1.Controls.Count - 1) / 2
                parametros += "@param" & i & ","
            Next
            Sql = "Insert into " & datos.SelectedItem.ToString & " values(" & parametros.Substring(0, parametros.Length - 1) & ")"
            Dim consulta As New OleDbCommand(Sql, BDCON)
            Dim arrayParam As String() = parametros.Substring(0, parametros.Length - 1).Split(",")
            Dim arrayVal As String() = valores.Substring(0, valores.Length - 1).Split("|")
            For i = 0 To arrayParam.Length - 1
                consulta.Parameters.AddWithValue(arrayParam(i), arrayVal(i))
            Next
            Dim result As Integer = consulta.ExecuteNonQuery

            MsgBox("Se ha hecho " & result & " inserciones a la base de datos.")
        Catch ex As Exception
            transaccion.Rollback()
        End Try
        Reto.desconectar()
    End Sub
    'Metodo para ir a la clase de visualizar la bdd en modo conectado
    Private Sub BaseDeDatosToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles BaseDeDatosToolStripMenuItem4.Click
        visualizar_bdd.Show()
        Me.Close()
    End Sub
    'Metodo para ir a la clase de visualizar la bdd en modo no conectado
    Private Sub AdaptadorToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles AdaptadorToolStripMenuItem4.Click
        visualizar_adaptador.Show()
        Me.Close()
    End Sub
End Class