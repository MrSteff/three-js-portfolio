﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MaskedYValidaciones
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MaskedTextBox6 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox5 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox4 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox3 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox2 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.FondoBotonesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlancoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FondoTextBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlancoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FondoFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlancoToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CambiarColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AzulToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerdeToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlancoToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(136, 348)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 44
        Me.Button2.Text = "Salir"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(17, 348)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 43
        Me.Button1.Text = "Aceptar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 295)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Codigo postal"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 255)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "Salario"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 214)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 13)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Fecha nacimiento"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 169)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Edad"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Telefono"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Nombre"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(215, 29)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Introduce tus datos"
        '
        'MaskedTextBox6
        '
        Me.MaskedTextBox6.Location = New System.Drawing.Point(111, 292)
        Me.MaskedTextBox6.Mask = "0 0 0 0 0"
        Me.MaskedTextBox6.Name = "MaskedTextBox6"
        Me.MaskedTextBox6.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox6.TabIndex = 35
        '
        'MaskedTextBox5
        '
        Me.MaskedTextBox5.Location = New System.Drawing.Point(111, 252)
        Me.MaskedTextBox5.Mask = "000.00€"
        Me.MaskedTextBox5.Name = "MaskedTextBox5"
        Me.MaskedTextBox5.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox5.TabIndex = 34
        '
        'MaskedTextBox4
        '
        Me.MaskedTextBox4.Location = New System.Drawing.Point(111, 211)
        Me.MaskedTextBox4.Mask = "00/00/0000"
        Me.MaskedTextBox4.Name = "MaskedTextBox4"
        Me.MaskedTextBox4.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox4.TabIndex = 33
        '
        'MaskedTextBox3
        '
        Me.MaskedTextBox3.Location = New System.Drawing.Point(111, 166)
        Me.MaskedTextBox3.Mask = "00"
        Me.MaskedTextBox3.Name = "MaskedTextBox3"
        Me.MaskedTextBox3.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox3.TabIndex = 32
        '
        'MaskedTextBox2
        '
        Me.MaskedTextBox2.Location = New System.Drawing.Point(111, 121)
        Me.MaskedTextBox2.Mask = "000-00-00-00"
        Me.MaskedTextBox2.Name = "MaskedTextBox2"
        Me.MaskedTextBox2.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox2.TabIndex = 31
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.Location = New System.Drawing.Point(111, 79)
        Me.MaskedTextBox1.Mask = "LLLLLLLLLLLLLLLLLLLL"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(100, 20)
        Me.MaskedTextBox1.TabIndex = 30
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(75, 393)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 45
        Me.Button3.Text = "Volver"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FondoBotonesToolStripMenuItem, Me.FondoTextBoxToolStripMenuItem, Me.FondoFormToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(155, 92)
        Me.ContextMenuStrip1.Text = "Cambiar fondos generales"
        '
        'FondoBotonesToolStripMenuItem
        '
        Me.FondoBotonesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AzulToolStripMenuItem, Me.VerdeToolStripMenuItem, Me.BlancoToolStripMenuItem})
        Me.FondoBotonesToolStripMenuItem.Name = "FondoBotonesToolStripMenuItem"
        Me.FondoBotonesToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.FondoBotonesToolStripMenuItem.Text = "Fondo Botones"
        '
        'AzulToolStripMenuItem
        '
        Me.AzulToolStripMenuItem.Name = "AzulToolStripMenuItem"
        Me.AzulToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.AzulToolStripMenuItem.Text = "Azul"
        '
        'VerdeToolStripMenuItem
        '
        Me.VerdeToolStripMenuItem.Name = "VerdeToolStripMenuItem"
        Me.VerdeToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.VerdeToolStripMenuItem.Text = "Verde"
        '
        'BlancoToolStripMenuItem
        '
        Me.BlancoToolStripMenuItem.Name = "BlancoToolStripMenuItem"
        Me.BlancoToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.BlancoToolStripMenuItem.Text = "Blanco"
        '
        'FondoTextBoxToolStripMenuItem
        '
        Me.FondoTextBoxToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AzulToolStripMenuItem1, Me.VerdeToolStripMenuItem1, Me.BlancoToolStripMenuItem1})
        Me.FondoTextBoxToolStripMenuItem.Name = "FondoTextBoxToolStripMenuItem"
        Me.FondoTextBoxToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.FondoTextBoxToolStripMenuItem.Text = "Fondo textBox"
        '
        'AzulToolStripMenuItem1
        '
        Me.AzulToolStripMenuItem1.Name = "AzulToolStripMenuItem1"
        Me.AzulToolStripMenuItem1.Size = New System.Drawing.Size(110, 22)
        Me.AzulToolStripMenuItem1.Text = "Azul"
        '
        'VerdeToolStripMenuItem1
        '
        Me.VerdeToolStripMenuItem1.Name = "VerdeToolStripMenuItem1"
        Me.VerdeToolStripMenuItem1.Size = New System.Drawing.Size(110, 22)
        Me.VerdeToolStripMenuItem1.Text = "Verde"
        '
        'BlancoToolStripMenuItem1
        '
        Me.BlancoToolStripMenuItem1.Name = "BlancoToolStripMenuItem1"
        Me.BlancoToolStripMenuItem1.Size = New System.Drawing.Size(110, 22)
        Me.BlancoToolStripMenuItem1.Text = "Blanco"
        '
        'FondoFormToolStripMenuItem
        '
        Me.FondoFormToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AzulToolStripMenuItem2, Me.VerdeToolStripMenuItem2, Me.BlancoToolStripMenuItem2})
        Me.FondoFormToolStripMenuItem.Name = "FondoFormToolStripMenuItem"
        Me.FondoFormToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.FondoFormToolStripMenuItem.Text = "Fondo Form"
        '
        'AzulToolStripMenuItem2
        '
        Me.AzulToolStripMenuItem2.Name = "AzulToolStripMenuItem2"
        Me.AzulToolStripMenuItem2.Size = New System.Drawing.Size(110, 22)
        Me.AzulToolStripMenuItem2.Text = "Azul"
        '
        'VerdeToolStripMenuItem2
        '
        Me.VerdeToolStripMenuItem2.Name = "VerdeToolStripMenuItem2"
        Me.VerdeToolStripMenuItem2.Size = New System.Drawing.Size(110, 22)
        Me.VerdeToolStripMenuItem2.Text = "Verde"
        '
        'BlancoToolStripMenuItem2
        '
        Me.BlancoToolStripMenuItem2.Name = "BlancoToolStripMenuItem2"
        Me.BlancoToolStripMenuItem2.Size = New System.Drawing.Size(110, 22)
        Me.BlancoToolStripMenuItem2.Text = "Blanco"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CambiarColorToolStripMenuItem, Me.SalirToolStripMenuItem1})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(150, 48)
        '
        'CambiarColorToolStripMenuItem
        '
        Me.CambiarColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AzulToolStripMenuItem3, Me.VerdeToolStripMenuItem3, Me.BlancoToolStripMenuItem3})
        Me.CambiarColorToolStripMenuItem.Name = "CambiarColorToolStripMenuItem"
        Me.CambiarColorToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.CambiarColorToolStripMenuItem.Text = "Cambiar color"
        '
        'AzulToolStripMenuItem3
        '
        Me.AzulToolStripMenuItem3.Name = "AzulToolStripMenuItem3"
        Me.AzulToolStripMenuItem3.Size = New System.Drawing.Size(110, 22)
        Me.AzulToolStripMenuItem3.Text = "Azul"
        '
        'VerdeToolStripMenuItem3
        '
        Me.VerdeToolStripMenuItem3.Name = "VerdeToolStripMenuItem3"
        Me.VerdeToolStripMenuItem3.Size = New System.Drawing.Size(110, 22)
        Me.VerdeToolStripMenuItem3.Text = "Verde"
        '
        'BlancoToolStripMenuItem3
        '
        Me.BlancoToolStripMenuItem3.Name = "BlancoToolStripMenuItem3"
        Me.BlancoToolStripMenuItem3.Size = New System.Drawing.Size(110, 22)
        Me.BlancoToolStripMenuItem3.Text = "Blanco"
        '
        'SalirToolStripMenuItem1
        '
        Me.SalirToolStripMenuItem1.Name = "SalirToolStripMenuItem1"
        Me.SalirToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.SalirToolStripMenuItem1.Text = "Salir"
        '
        'MaskedYValidaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(245, 450)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MaskedTextBox6)
        Me.Controls.Add(Me.MaskedTextBox5)
        Me.Controls.Add(Me.MaskedTextBox4)
        Me.Controls.Add(Me.MaskedTextBox3)
        Me.Controls.Add(Me.MaskedTextBox2)
        Me.Controls.Add(Me.MaskedTextBox1)
        Me.Name = "MaskedYValidaciones"
        Me.Text = "No he copiado >.>"
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents MaskedTextBox6 As MaskedTextBox
    Friend WithEvents MaskedTextBox5 As MaskedTextBox
    Friend WithEvents MaskedTextBox4 As MaskedTextBox
    Friend WithEvents MaskedTextBox3 As MaskedTextBox
    Friend WithEvents MaskedTextBox2 As MaskedTextBox
    Friend WithEvents MaskedTextBox1 As MaskedTextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents HelpProvider1 As HelpProvider
    Friend WithEvents ErrorProvider1 As ErrorProvider
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents FondoBotonesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BlancoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FondoTextBoxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents BlancoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents FondoFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents BlancoToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As ContextMenuStrip
    Friend WithEvents CambiarColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AzulToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents VerdeToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents BlancoToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem1 As ToolStripMenuItem
End Class
