﻿Imports System.ComponentModel

Public Class MaskedYValidaciones
    Dim index As Object

    Private Sub MaskedTextBox1_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles MaskedTextBox1.MaskInputRejected, MaskedTextBox2.MaskInputRejected, MaskedTextBox3.MaskInputRejected, MaskedTextBox4.MaskInputRejected, MaskedTextBox5.MaskInputRejected, MaskedTextBox6.MaskInputRejected
        ToolTip1.Show("Datos invalidos", sender, 5000)
    End Sub

    Private Sub keydown(sender As Object, e As KeyEventArgs) Handles MaskedTextBox1.KeyDown, MaskedTextBox2.KeyDown, MaskedTextBox3.KeyDown, MaskedTextBox4.KeyDown, MaskedTextBox5.KeyDown
        Dim prueba As String = MaskedTextBox1.Text.Replace("_", "")
        prueba = prueba.Replace(" ", "")

        If e.KeyCode = Keys.Enter And prueba.Equals("") And sender.Equals(MaskedTextBox1) Then
            ErrorProvider1.SetError(MaskedTextBox1, "Tiene que insertar un nombre.")
            MaskedTextBox1.Focus()
        ElseIf e.KeyCode = Keys.Enter And Not prueba.Equals("") And sender.Equals(MaskedTextBox1) Then
            ErrorProvider1.Clear()
            tab(sender, e)
        End If

        comprobacionPorElementos(sender, e, MaskedTextBox2)
        comprobacionPorElementos(sender, e, MaskedTextBox3)
        comprobacionPorElementos(sender, e, MaskedTextBox4)
        comprobacionPorElementos(sender, e, MaskedTextBox5)
    End Sub

    Private Sub lastKeydown(sender As Object, e As KeyEventArgs) Handles MaskedTextBox6.KeyDown
        If e.KeyCode = Keys.Enter And comprobacionPorElementos(sender, e, MaskedTextBox6) Then
            'Button1.Select()
            SendKeys.Send("{Enter}")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim prueba As String = MaskedTextBox1.Text.Replace("_", "")
        prueba = prueba.Replace(" ", "")
        If comprobacion() Then
            MsgBox("Nombre: " & prueba & vbCrLf & "Telefono: " & MaskedTextBox2.Text & vbCrLf & "Edad: " & MaskedTextBox3.Text & vbCrLf &
                   "Fecha nacimiento: " & MaskedTextBox4.Text & vbCrLf & "Salario: " & MaskedTextBox5.Text & vbCrLf & "Codigo postal: " & MaskedTextBox6.Text)
        End If
    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim respuesta As MsgBoxResult

        respuesta = MsgBox("Realmente quiere salir?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "Cerrando")

        If respuesta = respuesta.No Then
            e.Cancel = True
        End If
    End Sub

    Private Sub button2_click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        MaskedTextBox1.Focus()
        Me.HelpButton = True
        Me.MinimizeBox = False
        Me.MaximizeBox = False

        Me.HelpProvider1.SetHelpString(MaskedTextBox1, "Escriba El nombre")
        Me.HelpProvider1.SetHelpString(MaskedTextBox2, "Escriba El telefono")
        Me.HelpProvider1.SetHelpString(MaskedTextBox3, "Escriba la edada")
        Me.HelpProvider1.SetHelpString(MaskedTextBox4, "Escriba la fecha")
        Me.HelpProvider1.SetHelpString(MaskedTextBox5, "Escriba El salario")
        Me.HelpProvider1.SetHelpString(MaskedTextBox6, "Escriba El codigo postal")
        Me.HelpProvider1.SetHelpString(Button1, "Validar datos")
        Me.HelpProvider1.SetHelpString(Button2, "Salir del programa")

    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyData = (Keys.Control + Keys.Alt + Keys.E) Then
            Me.Close()
        End If
    End Sub

    Private Sub tab(sender As Object, e As KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Function comprobacionPorElementos(sender As Object, e As KeyEventArgs, objeto As MaskedTextBox) As Boolean
        If e.KeyCode = Keys.Enter And sender.Equals(objeto) And objeto.MaskFull Then
            ErrorProvider1.Clear()
            tab(sender, e)
            Return True
        ElseIf e.KeyCode = Keys.Enter And sender.Equals(objeto) And Not objeto.MaskFull Then
            ErrorProvider1.SetError(objeto, "Tiene que insertar un numero de telefono.")
            objeto.Focus()
            Return False
        End If
        Return False
    End Function

    Private Function comprobacion() As Boolean
        Dim prueba As String = MaskedTextBox1.Text.Replace("_", "")
        prueba = prueba.Replace(" ", "")
        If Not prueba.Equals("") And MaskedTextBox2.MaskFull And MaskedTextBox3.MaskFull And MaskedTextBox4.MaskFull And MaskedTextBox5.MaskFull And MaskedTextBox6.MaskFull Then
            Return True
        End If
        Return False
    End Function

    Private Sub AzulToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem.Click
        cambiarVariosColoresBotones(Color.Blue)
    End Sub

    Private Sub VerdeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem.Click
        cambiarVariosColoresBotones(Color.Green)
    End Sub

    Private Sub BlancoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem.Click
        cambiarVariosColoresBotones(Color.White)
    End Sub

    Private Sub AzulToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem1.Click
        cambiarVariosColoresTextFields(Color.Blue)
    End Sub
    Private Sub VerdeToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem1.Click
        cambiarVariosColoresTextFields(Color.Green)
    End Sub

    Private Sub BlancoToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem1.Click
        cambiarVariosColoresTextFields(Color.White)
    End Sub

    Private Sub AzulToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem2.Click
        cambiarColor(Me, Color.Blue)
    End Sub

    Private Sub VerdeToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem2.Click
        cambiarColor(Me, Color.Green)
    End Sub

    Private Sub BlancoToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem2.Click
        cambiarColor(Me, Color.White)
    End Sub

    Private Sub AzulToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles AzulToolStripMenuItem3.Click
        cambiarColor(index, Color.Blue)
    End Sub

    Private Sub VerdeToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles VerdeToolStripMenuItem3.Click
        cambiarColor(index, Color.Green)
    End Sub

    Private Sub BlancoToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles BlancoToolStripMenuItem3.Click
        cambiarColor(index, Color.White)
    End Sub

    Private Sub cambiarColor(obj As Object, color As Color)
        obj.BackColor = color
    End Sub

    Private Sub salirContextMenu(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click, SalirToolStripMenuItem1.Click
        Application.Exit()
    End Sub

    Private Sub MaskedTextBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles MaskedTextBox1.MouseDown, MaskedTextBox2.MouseDown, MaskedTextBox3.MouseDown, MaskedTextBox4.MouseDown, MaskedTextBox5.MouseDown, MaskedTextBox6.MouseDown, Button1.MouseDown, Button2.MouseDown
        If e.Button = MouseButtons.Right Then
            index = sender
        End If
    End Sub

    Private Sub cambiarVariosColoresTextFields(color As Color)
        For Each obj In Me.Controls
            If TypeOf obj Is MaskedTextBox Then
                cambiarColor(obj, color)
            End If
        Next
    End Sub

    Private Sub cambiarVariosColoresBotones(color As Color)
        For Each obj In Me.Controls
            If TypeOf obj Is Button Then
                cambiarColor(obj, color)
            End If
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        indice.Show()
        Me.Close()
    End Sub

    '0 Acepta un numero entre 0 y 9
    '9 Acepta un numero o un espacio
    'L Acepta una letra
    '? Acepta letra o espacio
    '00,00 Separador de decimales
    ': Separador de hora, minutos o segundos
    '/ fechas
    '$ € monedas
    '
    ' Definicion google 
    '0   Digit, required. Este elemento aceptará cualquier dígito único entre 0 y 9.
    '9   Dígito o espacio, opcional.
    '#	 Dígito o espacio, opcional. Si esta posición está en blanco en la máscara, se representará como un espacio en la Text propiedad. Se permiten signos más (+) y menos (-).
    'L	 Letter, required. Restringe la entrada a las letras ASCII a-z y A-Z. Este elemento de máscara es equivalente a [a-zA-Z] en expresiones regulares.
    '?   Letter, opcional. Restringe la entrada a las letras ASCII a-z y A-Z.
    '&	 Carácter requerido. Si la AsciiOnly propiedad se establece en true, este elemento se comporta como el elemento "L".
    'C	 Carácter, opcional. Cualquier carácter que no sea de control. Si la AsciiOnly propiedad se establece en True , este elemento se comporta como el elemento "?".
    'Un	 Alfanumérica, requerida. Si la AsciiOnly propiedad está establecida en True , los únicos caracteres que aceptarán son las letras ASCII a-z y a-z. Este elemento de máscara se comporta como el elemento "a".
    'a	 Alfanumérico, opcional. Si la AsciiOnly propiedad está establecida en True , los únicos caracteres que aceptarán son las letras ASCII a-z y a-z. Este elemento de máscara se comporta como el elemento "A".
    '.   Marcador de posición Decimal. El carácter de presentación real utilizado será el símbolo Decimal apropiado para el proveedor de formato, determinado por la propiedad del control FormatProvider .
    ',	 Marcador de posición de miles. El carácter de presentación real utilizado será el marcador de posición de miles apropiado para el proveedor de formato, según lo determinado por la propiedad del control FormatProvider .
    ':	 Separador de líneas. El carácter de presentación real utilizado será el símbolo de hora apropiado para el proveedor de formato, determinado por la propiedad del control FormatProvider .
    '/	 Separador de fecha. El carácter de presentación real utilizado será el símbolo de fecha apropiado para el proveedor de formato, determinado por la propiedad del control FormatProvider .
    '$	 Símbolo de moneda. El carácter real que se muestra será el símbolo de moneda apropiado para el proveedor de formato, determinado por la FormatProvider propiedad del control.
    '    <Desplazarse hacia abajo. Convierte todos los caracteres que siguen a minúsculas.
    '>	 Desplazar hacia arriba. Convierte todos los caracteres que siguen a mayúsculas.
    '|	 Deshabilitar un desplazamiento anterior o desplazarse hacia abajo.
    '\	 Salida. Escapa un carácter de máscara, convirtiéndolo en un literal. " \ \ " es la secuencia de escape para una barra diagonal inversa.


End Class