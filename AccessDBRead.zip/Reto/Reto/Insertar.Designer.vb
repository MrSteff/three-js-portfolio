﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class insertar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.datos = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.VisualisarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseDeDatosToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdaptadorToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'datos
        '
        Me.datos.FormattingEnabled = True
        Me.datos.Location = New System.Drawing.Point(337, 56)
        Me.datos.Name = "datos"
        Me.datos.Size = New System.Drawing.Size(121, 21)
        Me.datos.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(134, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "¿En que tabla quiere insertar datos?"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisualisarToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'VisualisarToolStripMenuItem
        '
        Me.VisualisarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BaseDeDatosToolStripMenuItem4, Me.AdaptadorToolStripMenuItem4})
        Me.VisualisarToolStripMenuItem.Name = "VisualisarToolStripMenuItem"
        Me.VisualisarToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.VisualisarToolStripMenuItem.Text = "Visualizar"
        '
        'BaseDeDatosToolStripMenuItem4
        '
        Me.BaseDeDatosToolStripMenuItem4.Name = "BaseDeDatosToolStripMenuItem4"
        Me.BaseDeDatosToolStripMenuItem4.Size = New System.Drawing.Size(146, 22)
        Me.BaseDeDatosToolStripMenuItem4.Text = "Base de datos"
        '
        'AdaptadorToolStripMenuItem4
        '
        Me.AdaptadorToolStripMenuItem4.Name = "AdaptadorToolStripMenuItem4"
        Me.AdaptadorToolStripMenuItem4.Size = New System.Drawing.Size(146, 22)
        Me.AdaptadorToolStripMenuItem4.Text = "Adaptador"
        '
        'Panel1
        '
        Me.Panel1.AutoSize = True
        Me.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.Location = New System.Drawing.Point(83, 104)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(0, 0)
        Me.Panel1.TabIndex = 9
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(473, 54)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(144, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Insertar sin parametros"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(623, 54)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(144, 23)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Insertar con parametros"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'insertar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.datos)
        Me.Name = "insertar"
        Me.Text = "Insertar"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents datos As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents VisualisarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BaseDeDatosToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents AdaptadorToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
