﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class visualizar_adaptador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.VisualisarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdaptadorToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.codcli = New System.Windows.Forms.ComboBox()
        Me.buscador = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.registro = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tablas = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AñadirXAlCampoSeleccionadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnElCampoSeleccionadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UltimoCaracterDelCampoDirecVenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElVendedorSeleccionadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarBDDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TipoSeleccionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FilaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CeldaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasDeUnaFilaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XmlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerarXmlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarDesdeXmlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BuscarVendedor = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ServiceController1 = New System.ServiceProcess.ServiceController()
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.BuscarVendedor.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisualisarToolStripMenuItem, Me.InsertToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'VisualisarToolStripMenuItem
        '
        Me.VisualisarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdaptadorToolStripMenuItem4})
        Me.VisualisarToolStripMenuItem.Name = "VisualisarToolStripMenuItem"
        Me.VisualisarToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.VisualisarToolStripMenuItem.Text = "Visualizar"
        '
        'AdaptadorToolStripMenuItem4
        '
        Me.AdaptadorToolStripMenuItem4.Name = "AdaptadorToolStripMenuItem4"
        Me.AdaptadorToolStripMenuItem4.Size = New System.Drawing.Size(146, 22)
        Me.AdaptadorToolStripMenuItem4.Text = "Base de datos"
        '
        'InsertToolStripMenuItem
        '
        Me.InsertToolStripMenuItem.Name = "InsertToolStripMenuItem"
        Me.InsertToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.InsertToolStripMenuItem.Text = "Insert"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.BuscarVendedor)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(0, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(800, 421)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.codcli)
        Me.TabPage1.Controls.Add(Me.buscador)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.registro)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.tablas)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(792, 395)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Ver Datos"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'codcli
        '
        Me.codcli.FormattingEnabled = True
        Me.codcli.Location = New System.Drawing.Point(629, 22)
        Me.codcli.Name = "codcli"
        Me.codcli.Size = New System.Drawing.Size(104, 21)
        Me.codcli.TabIndex = 15
        Me.codcli.Text = "Seleccionar CodCli"
        '
        'buscador
        '
        Me.buscador.Location = New System.Drawing.Point(455, 22)
        Me.buscador.Name = "buscador"
        Me.buscador.Size = New System.Drawing.Size(100, 20)
        Me.buscador.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(400, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Ir a la fila"
        '
        'registro
        '
        Me.registro.Location = New System.Drawing.Point(264, 21)
        Me.registro.Name = "registro"
        Me.registro.Size = New System.Drawing.Size(100, 20)
        Me.registro.TabIndex = 12
        Me.ToolTip1.SetToolTip(Me.registro, "Para eliminar el registro encontrado presiona enter." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(223, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Borrar"
        '
        'tablas
        '
        Me.tablas.FormattingEnabled = True
        Me.tablas.Location = New System.Drawing.Point(60, 21)
        Me.tablas.Name = "tablas"
        Me.tablas.Size = New System.Drawing.Size(121, 21)
        Me.tablas.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Tabla"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.DataGridView1.Location = New System.Drawing.Point(11, 60)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(773, 329)
        Me.DataGridView1.TabIndex = 8
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AñadirXAlCampoSeleccionadoToolStripMenuItem, Me.BorrarToolStripMenuItem, Me.ActualizarBDDToolStripMenuItem, Me.TipoSeleccionToolStripMenuItem, Me.XmlToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(151, 114)
        '
        'AñadirXAlCampoSeleccionadoToolStripMenuItem
        '
        Me.AñadirXAlCampoSeleccionadoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AlToolStripMenuItem, Me.EnElCampoSeleccionadoToolStripMenuItem, Me.AyudaToolStripMenuItem})
        Me.AñadirXAlCampoSeleccionadoToolStripMenuItem.Name = "AñadirXAlCampoSeleccionadoToolStripMenuItem"
        Me.AñadirXAlCampoSeleccionadoToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.AñadirXAlCampoSeleccionadoToolStripMenuItem.Text = "Añadir x"
        '
        'AlToolStripMenuItem
        '
        Me.AlToolStripMenuItem.Name = "AlToolStripMenuItem"
        Me.AlToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.AlToolStripMenuItem.Text = "En el capo DirecVen"
        '
        'EnElCampoSeleccionadoToolStripMenuItem
        '
        Me.EnElCampoSeleccionadoToolStripMenuItem.Name = "EnElCampoSeleccionadoToolStripMenuItem"
        Me.EnElCampoSeleccionadoToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.EnElCampoSeleccionadoToolStripMenuItem.Text = "En el campo seleccionado"
        '
        'AyudaToolStripMenuItem
        '
        Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.AyudaToolStripMenuItem.Text = "Ayuda"
        '
        'BorrarToolStripMenuItem
        '
        Me.BorrarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UltimoCaracterDelCampoDirecVenToolStripMenuItem, Me.ElVendedorSeleccionadoToolStripMenuItem, Me.RegistroToolStripMenuItem, Me.AyudaToolStripMenuItem1})
        Me.BorrarToolStripMenuItem.Name = "BorrarToolStripMenuItem"
        Me.BorrarToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.BorrarToolStripMenuItem.Text = "Borrar"
        '
        'UltimoCaracterDelCampoDirecVenToolStripMenuItem
        '
        Me.UltimoCaracterDelCampoDirecVenToolStripMenuItem.Name = "UltimoCaracterDelCampoDirecVenToolStripMenuItem"
        Me.UltimoCaracterDelCampoDirecVenToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.UltimoCaracterDelCampoDirecVenToolStripMenuItem.Text = "Ultimo caracter del campo DirecVen"
        '
        'ElVendedorSeleccionadoToolStripMenuItem
        '
        Me.ElVendedorSeleccionadoToolStripMenuItem.Name = "ElVendedorSeleccionadoToolStripMenuItem"
        Me.ElVendedorSeleccionadoToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.ElVendedorSeleccionadoToolStripMenuItem.Text = "Ultimo caracter del campo seleccionado"
        '
        'RegistroToolStripMenuItem
        '
        Me.RegistroToolStripMenuItem.Name = "RegistroToolStripMenuItem"
        Me.RegistroToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.RegistroToolStripMenuItem.Text = "Registro"
        '
        'AyudaToolStripMenuItem1
        '
        Me.AyudaToolStripMenuItem1.Name = "AyudaToolStripMenuItem1"
        Me.AyudaToolStripMenuItem1.Size = New System.Drawing.Size(286, 22)
        Me.AyudaToolStripMenuItem1.Text = "Ayuda"
        '
        'ActualizarBDDToolStripMenuItem
        '
        Me.ActualizarBDDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ActualizarToolStripMenuItem, Me.CargarToolStripMenuItem})
        Me.ActualizarBDDToolStripMenuItem.Name = "ActualizarBDDToolStripMenuItem"
        Me.ActualizarBDDToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.ActualizarBDDToolStripMenuItem.Text = "BDD"
        '
        'ActualizarToolStripMenuItem
        '
        Me.ActualizarToolStripMenuItem.Name = "ActualizarToolStripMenuItem"
        Me.ActualizarToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.ActualizarToolStripMenuItem.Text = "Actualizar"
        '
        'CargarToolStripMenuItem
        '
        Me.CargarToolStripMenuItem.Name = "CargarToolStripMenuItem"
        Me.CargarToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.CargarToolStripMenuItem.Text = "Cargar"
        '
        'TipoSeleccionToolStripMenuItem
        '
        Me.TipoSeleccionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilaToolStripMenuItem, Me.CeldaToolStripMenuItem, Me.MasDeUnaFilaToolStripMenuItem})
        Me.TipoSeleccionToolStripMenuItem.Name = "TipoSeleccionToolStripMenuItem"
        Me.TipoSeleccionToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.TipoSeleccionToolStripMenuItem.Text = "Tipo Seleccion"
        '
        'FilaToolStripMenuItem
        '
        Me.FilaToolStripMenuItem.Name = "FilaToolStripMenuItem"
        Me.FilaToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.FilaToolStripMenuItem.Text = "Fila"
        '
        'CeldaToolStripMenuItem
        '
        Me.CeldaToolStripMenuItem.Name = "CeldaToolStripMenuItem"
        Me.CeldaToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.CeldaToolStripMenuItem.Text = "Celda"
        '
        'MasDeUnaFilaToolStripMenuItem
        '
        Me.MasDeUnaFilaToolStripMenuItem.Name = "MasDeUnaFilaToolStripMenuItem"
        Me.MasDeUnaFilaToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.MasDeUnaFilaToolStripMenuItem.Text = "Mas de una fila"
        '
        'XmlToolStripMenuItem
        '
        Me.XmlToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GenerarXmlToolStripMenuItem, Me.CargarDesdeXmlToolStripMenuItem, Me.InfoToolStripMenuItem})
        Me.XmlToolStripMenuItem.Name = "XmlToolStripMenuItem"
        Me.XmlToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.XmlToolStripMenuItem.Text = "Xml"
        '
        'GenerarXmlToolStripMenuItem
        '
        Me.GenerarXmlToolStripMenuItem.Name = "GenerarXmlToolStripMenuItem"
        Me.GenerarXmlToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.GenerarXmlToolStripMenuItem.Text = "Generar xml"
        '
        'CargarDesdeXmlToolStripMenuItem
        '
        Me.CargarDesdeXmlToolStripMenuItem.Name = "CargarDesdeXmlToolStripMenuItem"
        Me.CargarDesdeXmlToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.CargarDesdeXmlToolStripMenuItem.Text = "Cargar desde xml"
        '
        'InfoToolStripMenuItem
        '
        Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
        Me.InfoToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.InfoToolStripMenuItem.Text = "Info"
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(792, 395)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Seleccionados"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'BuscarVendedor
        '
        Me.BuscarVendedor.Controls.Add(Me.Label4)
        Me.BuscarVendedor.Controls.Add(Me.TextBox1)
        Me.BuscarVendedor.Controls.Add(Me.DataGridView2)
        Me.BuscarVendedor.Location = New System.Drawing.Point(4, 22)
        Me.BuscarVendedor.Name = "BuscarVendedor"
        Me.BuscarVendedor.Padding = New System.Windows.Forms.Padding(3)
        Me.BuscarVendedor.Size = New System.Drawing.Size(792, 395)
        Me.BuscarVendedor.TabIndex = 2
        Me.BuscarVendedor.Text = "Buscar Vendedores"
        Me.BuscarVendedor.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Buscar por nombre"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(108, 6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.TextBox1, "Para eliminar el registro encontrado presiona enter.")
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(3, 32)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(789, 360)
        Me.DataGridView2.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TextBox2)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.DataGridView3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(792, 395)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Ver Peliculas"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(33, 17)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.TextBox2, "Para eliminar el registro encontrado presiona enter.")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(0, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Pais"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(3, 49)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(786, 340)
        Me.DataGridView3.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.ReportViewer1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(792, 395)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "Factura"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "Reto.Report1.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(3, 3)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.ServerReport.BearerToken = Nothing
        Me.ReportViewer1.Size = New System.Drawing.Size(786, 389)
        Me.ReportViewer1.TabIndex = 0
        '
        'visualizar_adaptador
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "visualizar_adaptador"
        Me.Text = "Adaptador"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.BuscarVendedor.ResumeLayout(False)
        Me.BuscarVendedor.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents VisualisarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdaptadorToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents InsertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents tablas As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents AñadirXAlCampoSeleccionadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnElCampoSeleccionadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BorrarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UltimoCaracterDelCampoDirecVenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ElVendedorSeleccionadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ActualizarBDDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TipoSeleccionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FilaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CeldaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MasDeUnaFilaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents registro As TextBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents buscador As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BuscarVendedor As TabPage
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents codcli As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ActualizarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents XmlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GenerarXmlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CargarDesdeXmlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CargarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents ServiceController1 As ServiceProcess.ServiceController
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents AyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents InfoToolStripMenuItem As ToolStripMenuItem
End Class
