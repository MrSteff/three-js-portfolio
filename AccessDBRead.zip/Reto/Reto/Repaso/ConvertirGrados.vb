﻿Public Class ConvertirGrados
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label3.Text = HScrollBar1.Value
        Label4.Text = (HScrollBar1.Value * 9 / 5) + 32
    End Sub

    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar1.Scroll
        Label3.Text = HScrollBar1.Value
        Label4.Text = (HScrollBar1.Value * 9 / 5) + 32
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        indice.Show()
        Me.Close()
    End Sub
End Class