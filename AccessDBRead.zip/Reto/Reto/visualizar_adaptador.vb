﻿Imports System.Data.OleDb
Imports Microsoft.Reporting.WinForms

Public Class visualizar_adaptador
    'Cargar el desplegable que contiene todas las tablas
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i = 0 To almacen.Tables.Count - 1
            tablas.Items.Add(almacen.Tables(i).TableName)
        Next
        'ordenar la tabla para rellenar el desplegable con los codigos de los clientes.
        Dim previo As DataView = almacen.Tables(0).DefaultView

        almacen.Tables(0).DefaultView.Sort = "CodCli ASC"
        'cargar el desplegable con todos los codigos de los clientes
        For Each fila As DataRowView In almacen.Tables(0).DefaultView
            codcli.Items.Add(fila(0).ToString)
        Next

        almacen.Tables(0).DefaultView.Sort = previo.Sort
    End Sub
    'metodo para ir a la clase de insertar en modo conectado.
    Private Sub InsertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InsertToolStripMenuItem.Click
        insertar.Show()
        Me.Close()
    End Sub
    'metodo para ir a la clase de visualizar en modo conectado.
    Private Sub AdaptadorToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles AdaptadorToolStripMenuItem4.Click
        visualizar_bdd.Show()
        Me.Close()
    End Sub
    'Metodo para rellenar el DataGridView y formatear los label, textbox y combobox que haya al lado.
    Private Sub tabla_DropDownClosed(sender As Object, e As EventArgs) Handles tablas.DropDownClosed
        If Not tablas.SelectedIndex = -1 Then
            Try
                DataGridView1.DataSource = almacen.Tables(tablas.SelectedItem.ToString)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            'Cambiar el contenido del label.
            Label2.Text = "Borrar por " & almacen.Tables(tablas.SelectedItem.ToString).Columns(0).ColumnName
            'mover los componentes dependiendo uno del otro.
            Dim point As Point = New Point(Label2.Location.X + registro.Width, Label2.Location.Y - 5)
            registro.Location = point
            point = New Point(registro.Location.X + registro.Width + Label3.Width, Label2.Location.Y)
            Label3.Location = point
            point = New Point(Label3.Location.X + buscador.Width, Label3.Location.Y - 5)
            buscador.Location = point
            point = New Point(buscador.Location.X + codcli.Width, Label3.Location.Y - 5)
            codcli.Location = point
        End If
    End Sub
    'Metodo de añadir una x al campo direcven de la primera fila.
    Private Sub AlToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AlToolStripMenuItem.Click
        DataGridView1.DataSource = almacen.Tables(almacen.Tables.Count - 1)
        DataGridView1.Rows(0).Cells(3).Value = DataGridView1.Rows(0).Cells(3).Value & "x"
    End Sub
    'metodo para añadir una x al campo seleccionado.
    'Este metodo solo añadira una x a la primera celda seleccionada.
    Private Sub EnElCampoSeleccionadoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EnElCampoSeleccionadoToolStripMenuItem.Click
        DataGridView1.SelectedCells(0).Value = DataGridView1.SelectedCells(0).Value & "x"
    End Sub
    'Metodo para borrar el ultimo caracter del direven de la primera fila.
    Private Sub UltimoCaracterDelCampoDirecVenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UltimoCaracterDelCampoDirecVenToolStripMenuItem.Click
        DataGridView1.DataSource = almacen.Tables(almacen.Tables.Count - 1)
        DataGridView1.Rows(0).Cells(3).Value = DataGridView1.Rows(0).Cells(3).Value.ToString.Substring(0, DataGridView1.Rows(0).Cells(3).Value.ToString.Length - 2)
    End Sub
    'Metodo para borrar el ultimo caracter del campo seleccionado.
    'Este metodo solo borrara el ultimo caracter de la primera celda seleccionada.
    Private Sub ElVendedorSeleccionadoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ElVendedorSeleccionadoToolStripMenuItem.Click
        DataGridView1.SelectedCells(0).Value = DataGridView1.SelectedCells(0).Value.ToString.Substring(0, DataGridView1.SelectedCells(0).Value.ToString.Length - 1)
    End Sub
    'Metodo para borrar la fila seleccionada en el DataGridView
    Private Sub RegistroToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistroToolStripMenuItem.Click
        Try
            Dim array As ArrayList = New ArrayList()
            If DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect And DataGridView1.MultiSelect = False Then 'Caso de solo poder seleccionar una fila entera
                array.Add(almacen.Tables(tablas.SelectedItem.ToString).Rows(DataGridView1.SelectedRows(0).Index).ToString)
                borrarCascade(almacen.Tables(tablas.SelectedIndex), 0, array)
                almacen.Tables(tablas.SelectedItem.ToString).Rows(DataGridView1.SelectedRows(0).Index).Delete()
                'borrar desde el datagridview independientemente del almacen.
                'DataGridView1.Rows.Remove(DataGridView1.SelectedRows(0))
            ElseIf DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect And DataGridView1.MultiSelect = True Then 'Caso de poder seleccionar varias filas enteras
                For Each fila In DataGridView1.SelectedRows
                    array.Add(almacen.Tables(tablas.SelectedItem.ToString).Rows(fila.Index).ToString)
                    borrarCascade(almacen.Tables(tablas.SelectedIndex), 0, array)
                    almacen.Tables(tablas.SelectedItem.ToString).Rows(fila.Index).Delete()
                    'borrar desde el datagridview independientemente del almacen.
                    'DataGridView1.Rows.Remove(fila)
                Next
            ElseIf DataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect And DataGridView1.MultiSelect = False Then 'Caso de poder seleccionar solo una celda
                array.Add(almacen.Tables(tablas.SelectedItem.ToString).Rows(DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex).Index).ToString)
                borrarCascade(almacen.Tables(tablas.SelectedIndex), 0, array)
                almacen.Tables(tablas.SelectedItem.ToString).Rows(DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex).Index).Delete()
                'borrar desde el datagridview independientemente del almacen.
                'DataGridView1.Rows.Remove(DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex))
            ElseIf DataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect And DataGridView1.MultiSelect = True Then 'Caso de poder seleccionar varias celdas
                For Each celda In DataGridView1.SelectedCells
                    Try
                        array.Add(almacen.Tables(tablas.SelectedItem.ToString).Rows(celda.RowIndex).ToString)
                        borrarCascade(almacen.Tables(tablas.SelectedIndex), 0, array)
                        almacen.Tables(tablas.SelectedItem.ToString).Rows(celda.RowIndex).Delete()
                        'borrar desde el datagridview independientemente del almacen.
                        'DataGridView1.Rows.Remove(DataGridView1.Rows(celda.RowIndex))
                    Catch ex As Exception
                    End Try
                Next
            End If
            MsgBox("La fila y todos los datos relacionados se han borrado correctamente.")
        Catch ex As Exception
            MsgBox("Se produjo un error al intentar borrar el registro seleccionado.")
        End Try
    End Sub
    'Metodo para cambiar a modo de seleccionar una fila entera.
    Private Sub FilaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FilaToolStripMenuItem.Click
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGridView1.Rows(0).Selected = True
    End Sub
    'Metodo para cambiar a modo de seleccionar solo una celda
    Private Sub CeldaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CeldaToolStripMenuItem.Click
        DataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect
        DataGridView1.Rows(0).Cells(0).Selected = True
    End Sub
    'Metodo para poder seleccionar mas de una fila
    'Volver ha llamar el metodo para desactivarlo.
    Private Sub MasDeUnaFilaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MasDeUnaFilaToolStripMenuItem.Click
        If DataGridView1.MultiSelect = True Then
            DataGridView1.MultiSelect = False
        Else
            DataGridView1.MultiSelect = True
        End If
        DataGridView1.Rows(0).Cells(0).Selected = True
    End Sub
    'Metodo para borrar la fila encontrada.
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles registro.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            If MsgBox("¿Quiere borrar este registro?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes And (Not DataGridView1.SelectedRows.Count - 1) Or Not DataGridView1.SelectedCells.Count - 1 Then
                If DataGridView1.MultiSelect = False Then
                    If DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect Then
                        DataGridView1.Rows.Remove(DataGridView1.SelectedRows(0))
                    Else
                        DataGridView1.Rows.Remove(DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex))
                    End If
                    registro.Text = ""
                Else
                    MsgBox("Solo puede borrar una linea a la vez.")
                End If
            End If
        End If
    End Sub
    'Metodo para buscar el dato escrito en el TextBox.
    Private Sub registro_TextChanged(sender As Object, e As EventArgs) Handles registro.TextChanged
        Dim encontrar As DataView = New DataView(almacen.Tables(tablas.SelectedItem.ToString))
        encontrar.Sort = almacen.Tables(tablas.SelectedItem.ToString).Columns(0).ColumnName
        Try

            If Not encontrar.Find(registro.Text) = -1 Then
                If DataGridView1.MultiSelect = True Then
                    DataGridView1.SelectedRows(DataGridView1.SelectedCells(0).RowIndex).Selected = False
                End If

                DataGridView1.Rows(encontrar.Find(registro.Text)).Cells(0).Selected = True
            End If
        Catch ex As Exception
        End Try
    End Sub
    'Metodo para construir la vista del panel siguiente.
    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedIndex = 1 Then

            Dim x As Integer = 20

            TabControl1.TabPages(1).Controls.Clear()
            Dim label As Label
            Dim dato As TextBox
            Dim botonUpdate1 = New System.Windows.Forms.Button
            Dim botonUpdate2 = New System.Windows.Forms.Button
            Dim item As DataGridViewRow
            botonUpdate1.Visible = True
            botonUpdate2.Visible = True

            Try
                item = DataGridView1.Rows(DataGridView1.SelectedCells(0).RowIndex)

                For i = 0 To item.Cells.Count - 1
                    label = New System.Windows.Forms.Label()
                    label.AutoSize = True
                    label.Location = New System.Drawing.Point(150, x)
                    x += 2
                    label.Name = "label" & (i + 1)
                    label.Size = New System.Drawing.Size(50, 20)
                    label.TabIndex = i
                    label.Text = DataGridView1.Columns(i).Name & ": "

                    TabControl1.TabPages(1).Controls.Add(label)

                    If item.Cells(i).Value.ToString.ToLower = "false" Or item.Cells(i).Value.ToString.ToLower = "true" Then
                        Dim lista As ComboBox = New System.Windows.Forms.ComboBox()
                        lista.FormattingEnabled = True
                        lista.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        x += 40
                        lista.Name = "dato" & (i + 1)
                        lista.Size = New System.Drawing.Size(121, 21)
                        lista.Items.Add("False")
                        lista.Items.Add("True")

                        If item.Cells(i).Value.ToString.ToLower = "false" Then
                            lista.SelectedIndex = 0
                        Else
                            lista.SelectedIndex = 1
                        End If

                        TabControl1.TabPages(1).Controls.Add(lista)
                    ElseIf label.Text.ToLower.Contains("fec") Then
                        Dim fecha As DateTimePicker = New System.Windows.Forms.DateTimePicker()

                        fecha.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        fecha.Name = "dato" & (i + 1)
                        fecha.Size = New System.Drawing.Size(200, 20)
                        fecha.Format = DateTimePickerFormat.Custom
                        fecha.CustomFormat = "MM/dd/yyyy"

                        Dim valorFecha As String() = item.Cells(i).Value.ToString.Substring(0, item.Cells(i).Value.ToString.IndexOf(" ")).Split("/")
                        fecha.Value = New Date(valorFecha(2), valorFecha(0), valorFecha(1))
                        x += 40
                        TabControl1.TabPages(1).Controls.Add(fecha)
                    Else
                        dato = New System.Windows.Forms.TextBox()
                        dato.AutoSize = False
                        dato.Location = New System.Drawing.Point(label.Width + 150, x - 5)
                        x += 40
                        dato.Name = "dato" & (i + 1)
                        dato.Size = New System.Drawing.Size(DataGridView1.Columns(i).Width, 20)
                        dato.Text = item.Cells(i).Value.ToString
                        If i = 0 Then
                            dato.Enabled = False
                        End If

                        TabControl1.TabPages(1).Controls.Add(dato)
                    End If


                Next
            Catch ex As Exception
                label = New System.Windows.Forms.Label()
                label.AutoSize = True
                label.Location = New System.Drawing.Point(90, 90)
                label.Name = "error"
                label.Size = New System.Drawing.Size(75, 13)
                label.TabIndex = 6
                label.Text = "No se ha seleccionado ningun dato."

                TabControl1.TabPages(1).Controls.Add(label)
                botonUpdate1.Visible = False
                botonUpdate2.Visible = False
            End Try
        ElseIf TabControl1.SelectedIndex = 2 Then
            DataGridView2.DataSource = almacen.Tables(7)
        ElseIf TabControl1.SelectedIndex = 3 Then
            Dim SQL As String
            Dim consulta As OleDbCommand
            Dim oledbCmdBuilder As OleDbCommandBuilder

            SQL = "Select * from Peliculas order by pais"
            consulta = New OleDbCommand(SQL, BDCON)
            adaptador = New OleDbDataAdapter(consulta)
            oledbCmdBuilder = New OleDbCommandBuilder(adaptador)
            adaptador.Fill(almacen, "Peliculas")
            DataGridView3.DataSource = almacen.Tables(5)
        End If
    End Sub
    'Metodo para ir a la fila escrita en el TextBox.
    Private Sub buscador_TextChanged(sender As Object, e As EventArgs) Handles buscador.TextChanged
        If Not tablas.SelectedIndex = -1 Then
            Try
                If Not buscador.Text = "" And Char.IsDigit(buscador.Text) And (Integer.Parse(buscador.Text) - 1) < DataGridView1.Rows.Count Then
                    DataGridView1.Rows(Integer.Parse(buscador.Text) - 1).Cells(0).Selected = True
                    DataGridView1.FirstDisplayedScrollingRowIndex = DataGridView1.SelectedRows(0).Index
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub
    'Metodo para calcular el importe del cliente seleccionado en el desplegable.
    Private Sub codcli_DropDownClosed(sender As Object, e As EventArgs) Handles codcli.DropDownClosed
        Dim acumulador As Integer
        For Each fila In almacen.Tables(1).Rows
            If fila(2).ToString = codcli.SelectedItem.ToString Then
                acumulador += fila(4)
            End If
        Next
        MsgBox("El importe total de " & almacen.Tables(0).Rows.Find(codcli.SelectedItem)(1).ToString & " es de " & acumulador & " €")
    End Sub
    'Metodo para buscar vendedores por nombre.
    'Se podira mejorar mucho pensando mas e como funciona las selecciones y quitar algunos try catch
    Private Sub buscar(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            Dim encontrado As Boolean = False
            Dim contador As Integer
            If DataGridView2.SelectionMode = DataGridViewSelectionMode.CellSelect Then
                DataGridView2.Rows(DataGridView2.SelectedCells(0).RowIndex).Selected = True
            End If


            contador = DataGridView2.Rows(DataGridView2.SelectedCells(0).RowIndex).Index + 1


            While Not encontrado And Not contador >= DataGridView2.Rows.Count - 1
                If DataGridView2.Rows(contador).Cells(1).Value.ToString.ToLower.Contains(TextBox1.Text.ToLower) Then

                    DataGridView2.Rows(DataGridView2.SelectedCells(0).RowIndex).Selected = False
                    DataGridView2.Rows(contador).Selected = True

                    encontrado = True
                End If
                contador += 1
            End While

            If encontrado = False Then
                DataGridView2.Rows(DataGridView2.SelectedCells(0).RowIndex).Selected = False
                DataGridView2.Rows(0).Selected = True
                DataGridView2.FirstDisplayedScrollingRowIndex = DataGridView2.Rows(DataGridView2.SelectedCells(0).RowIndex).Index
            End If
        End If
    End Sub
    'Metodo actualizar el dataset a la base de datos
    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem.Click
        'Como actualizar las tablas anteriores no funciona solo actualizaremos la tabla padre.
        'actualizarBDD(almacen.Tables(tablas.SelectedIndex))
        Dim cb As New OleDb.OleDbCommandBuilder(adaptador)

        adaptador.Update(almacen, almacen.Tables(tablas.SelectedIndex).TableName)

        Try
            almacen.AcceptChanges()
            MsgBox("Se ha actualizado la base de datos.")
        Catch ex As Exception
            MsgBox("No se ha actualizado la base de datos.")
        End Try

    End Sub
    'Metodo de cargar el almacen
    Private Sub CargarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CargarToolStripMenuItem.Click
        cargarAlmacen()
        MsgBox("El almacen se cargo con los datos de la base de datos.")
    End Sub
    'Metodo para generar el fichero xml con el dataset actual.
    Private Sub GenerarXmlToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GenerarXmlToolStripMenuItem.Click
        generarXML()
    End Sub
    'Metodo para cargar el almacen con el xml creado mas recien.
    Private Sub CargarDesdeXmlToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CargarDesdeXmlToolStripMenuItem.Click
        cargarDesdeXML()
    End Sub
    'Metodo para borrar todas las lineas relacionadas a la tabla padre recursivamente.
    Private Sub borrarCascade(tabla As DataTable, index As Integer, datos As ArrayList)
        For x = tabla.ChildRelations.Count - 1 To 0 Step -1
            Try
                If tabla.ChildRelations.Count > 0 Then 'comprobar si tiene mas tablas hijo
                    Dim collection As ArrayList = New ArrayList
                    For i = 0 To tabla.Rows.Count - 1
                        For y = 0 To datos.Count - 1
                            If tabla.Rows(i).Item(0).ToString = datos.Item(y).ToString Then 'En caso de tenerlo crear un arraylist con todas las lineas que relacionan la tabla padre
                                collection.Add(tabla.Rows(i).Item(0).ToString)
                            End If
                        Next
                    Next
                    borrarCascade(tabla.ChildRelations(x).ChildTable, 0, collection) 'Y mandarlo al hijo
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Next
        If tabla.ParentRelations.Count > 0 Then 'si no tiene mas tablas hijo se borra todas las filas que contenga datos relacionados y vuelve para atras para borrar las filas de la tabla que relaciona a esta
            For i = tabla.Rows.Count - 1 To 0 Step -1
                For x = datos.Count - 1 To 0 Step -1
                    If tabla.Rows(i).Item(index).ToString = datos.Item(0).ToString Then
                        tabla.Rows(i).Delete()
                    End If
                Next
            Next
        End If
    End Sub
    'Metodo para buscar las peliculas en el pais insertado.
    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If Asc(e.KeyChar) = Keys.Enter And Not TextBox2.Text = "" Then
            conectar()

            Dim SQL As String
            Dim consulta As OleDbCommand
            Dim adaptadorPelis As OleDbDataAdapter
            Dim almacenPelis As New DataSet

            SQL = "Select * from Peliculas where Pais = @pais order by Pais"
            consulta = New OleDbCommand(SQL, BDCON)
            consulta.Parameters.AddWithValue("@pais", TextBox2.Text.ToUpper)
            adaptadorPelis = New OleDbDataAdapter(consulta)
            adaptadorPelis.Fill(almacenPelis, "tabla")

            desconectar()

            DataGridView3.DataSource = almacenPelis.Tables(0)
        ElseIf Asc(e.KeyChar) = Keys.Enter Then
            conectar()

            Dim SQL As String
            Dim consulta As OleDbCommand
            Dim adaptadorPelis As OleDbDataAdapter
            Dim almacenPelis As New DataSet

            SQL = "Select * from Peliculas order by Pais"
            consulta = New OleDbCommand(SQL, BDCON)
            adaptadorPelis = New OleDbDataAdapter(consulta)
            adaptadorPelis.Fill(almacenPelis, "tabla")

            desconectar()

            DataGridView3.DataSource = almacenPelis.Tables(0)
        End If
    End Sub
    'Metodo para cargar el reportview (si funcionase)
    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load
        'Extensiones -> administra extensiones -> rdlc instalar -> reiniciar vb
        'Agregar un nuevo elemento -> informe
        Dim consulta As OleDbCommand
        Dim result As OleDbDataReader
        Dim almacenLocal As New EMPRESADataSet
        Dim Sql As String

        Sql = "SELECT f.Fecha, f.CodFac, c.CodCli, c.NombCli, f.Importe, f.IVA, c.CP, c.CodLoc" &
                " FROM Clientes c, Facturas f WHERE f.CodCli = c.CodCli and f.Fecha BETWEEN #1/1/1900# AND #1/1/2020# ORDER BY f.Fecha"

        conectar()
        consulta = New OleDbCommand(Sql, BDCON)
        adaptador = New OleDbDataAdapter(consulta)
        consulta.CommandType = CommandType.Text
        result = consulta.ExecuteReader
        result.Close()
        adaptador.Fill(almacenLocal, "TablaFactura")

        Dim rds As ReportDataSource = New ReportDataSource("ReporteFactura", almacenLocal.Tables(0))
        'rds.Name = "ReporteFactura"
        'rds.Value = almacenLocal.Tables(0)


        With ReportViewer1
            .LocalReport.ReportEmbeddedResource = "Reto.Report1.rdlc"
            .LocalReport.DataSources.Clear()
            .LocalReport.DataSources.Add(rds)
            .RefreshReport()
            .Text = "Reporte General"
        End With
        MsgBox("Ha sido un buen intento pero esto no funciona...")
        desconectar()
    End Sub
    'Metodo para ayudar al cliente.
    Private Sub AyudaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AyudaToolStripMenuItem.Click
        MsgBox("En caso de tener seleccionado una fila entera solo se añadira una x a la primera celda de estas.")
    End Sub
    'Metodo para ayudar al cliente.
    Private Sub AyudaToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AyudaToolStripMenuItem1.Click
        MsgBox("En caso de tener seleccionado una fila entera solo se quitara el ultimo caracter de la primera celda seleccionada." & vbCrLf &
               "Para borrar la fila entera selecciona la opcion Borrar -> Registro.")
    End Sub
    'Metodo para ayudar al cliente.
    Private Sub InfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InfoToolStripMenuItem.Click
        MsgBox("Al cargar el programa desde el xml se usara el xml creado mas reciente.")
    End Sub

    'Metodo recursivo que actualiza todas las tablas hijo hasta el padre (obsoleto)
    Private Sub actualizarBDD(tabla As DataTable)
        For x = tabla.ChildRelations.Count - 1 To 0 Step -1
            Try
                If tabla.ChildRelations.Count > 0 Then
                    actualizarBDD(tabla.ChildRelations(x).ChildTable) 'encontrar la ultima tabla relacionada
                End If
            Catch ex As Exception
                'MsgBox(ex.Message & " --- " & x)
            End Try
        Next
        adaptador.Update(almacen, tabla.TableName) 'actualizar la ultima tabla primero y luego volver para atras y actualizar todos los padres.
    End Sub
End Class